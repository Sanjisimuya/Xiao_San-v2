// ============================================================
// DATABASE 150 SOAL HOTS TKP & SEKDIN PKN STAN 2026
// Format: { id, bagian, pertanyaan, opsi[A-E], bobot{A-E}, kunci, pembahasan }
// ============================================================

window.BANK_SOAL = [
  {
    id: 1, bagian: "A",
    pertanyaan: "Anda adalah admin SP4N-LAPOR! di sebuah dinas. Sebuah pengaduan masyarakat yang bersifat normatif (tidak memerlukan pengawasan lapangan) masuk ke sistem pada tanggal 3 April 2026. Berdasarkan PermenPAN-RB Nomor 5 Tahun 2025, batas maksimal tindak lanjut pengaduan ini adalah…",
    opsi: { A: "3 hari kerja", B: "5 hari kerja", C: "14 hari kerja", D: "30 hari kerja", E: "60 hari kerja" },
    bobot: { A: 2, B: 5, C: 3, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Berdasarkan PermenPAN-RB No. 5/2025, pengaduan normatif (tidak memerlukan verifikasi lapangan) wajib ditindaklanjuti maksimal 5 hari kerja."
  },
  {
    id: 2, bagian: "A",
    pertanyaan: "Sebagai Pejabat Penghubung SP4N-LAPOR!, Anda menerima laporan masyarakat yang memerlukan verifikasi lapangan karena menyangkut dugaan pelanggaran prosedur di unit layanan terpencil. Sesuai regulasi terbaru, berapa batas maksimal penyelesaian untuk kategori pengaduan ini?",
    opsi: { A: "3 hari kerja", B: "14 hari kerja", C: "30 hari kerja", D: "60 hari kerja", E: "90 hari kerja" },
    bobot: { A: 1, B: 2, C: 2, D: 5, E: 2 }, kunci: "D",
    pembahasan: "Pengaduan yang memerlukan verifikasi lapangan/pengawasan punya batas maksimal 60 hari kerja sesuai PermenPAN-RB No. 5/2025."
  },
  {
    id: 3, bagian: "A",
    pertanyaan: "Instansi Anda sedang melakukan revitalisasi Pos Pengaduan Masyarakat. Dalam proses ini, Wamen LH menyampaikan bahwa prosedur tindak lanjut pengaduan untuk permintaan informasi maksimal dilakukan dalam waktu… Berdasarkan data real, berapa hari yang dimaksud?",
    opsi: { A: "1 hari kerja", B: "3 hari kerja", C: "5 hari kerja", D: "7 hari kerja", E: "14 hari kerja" },
    bobot: { A: 1, B: 2, C: 5, D: 3, E: 2 }, kunci: "C",
    pembahasan: "Permintaan informasi termasuk kategori pengaduan ringan dengan batas maksimal 5 hari kerja."
  },
  {
    id: 4, bagian: "A",
    pertanyaan: "Anda menerima pengaduan masyarakat yang sifatnya lintas unit kerja. Koordinasi dengan unit terkait masih dilakukan secara manual dan memakan waktu. Berdasarkan temuan evaluasi SP4N-LAPOR!, apa akar masalah utama yang perlu segera dibenahi?",
    opsi: { A: "Kurangnya fitur aplikasi", B: "Keterbatasan anggaran", C: "Variasi kompetensi SDM pengelola yang tidak merata", D: "Lemahnya komitmen pimpinan", E: "Kurangnya sosialisasi ke masyarakat" },
    bobot: { A: 3, B: 2, C: 5, D: 4, E: 2 }, kunci: "C",
    pembahasan: "Evaluasi nasional SP4N-LAPOR! mengidentifikasi variasi kompetensi SDM pengelola sebagai akar masalah utama yang menyebabkan koordinasi lintas unit lambat."
  },
  {
    id: 5, bagian: "A",
    pertanyaan: "Dalam rapat evaluasi SP4N-LAPOR!, ditemukan bahwa mekanisme auto-close sistem belum optimal. Tindakan apa yang paling tepat dilakukan sebagai admin utama?",
    opsi: { A: "Membiarkan sistem bekerja secara otomatis tanpa intervensi", B: "Memperpanjang batas waktu auto-close tanpa koordinasi", C: "Melaporkan ke atasan untuk perbaikan teknis dan pengaturan ulang parameter auto-close", D: "Menonaktifkan fitur auto-close sementara waktu", E: "Memindahkan semua pengaduan ke kanal WhatsApp" },
    bobot: { A: 1, B: 2, C: 5, D: 3, E: 2 }, kunci: "C",
    pembahasan: "Tindakan paling akuntabel: laporkan ke atasan untuk perbaikan teknis dengan tetap menjalankan SOP."
  },
  {
    id: 6, bagian: "A",
    pertanyaan: "Ombudsman RI menekankan pentingnya integrasi SP4N-LAPOR! dengan SIMPeL. Apa manfaat utama dari integrasi ini?",
    opsi: { A: "Mempermudah masyarakat dalam mengirimkan foto", B: "Memastikan setiap aduan masyarakat ditindaklanjuti secara tuntas dengan pengawasan eksternal", C: "Mengurangi jumlah pengaduan yang masuk", D: "Mempercepat promosi jabatan admin pengaduan", E: "Menggantikan peran unit pengaduan internal" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Integrasi SP4N-LAPOR! dengan SIMPeL Ombudsman memungkinkan pengawasan eksternal sehingga aduan benar-benar tuntas, bukan sekadar 'selesai administratif'."
  },
  {
    id: 7, bagian: "A",
    pertanyaan: "Dalam hasil evaluasi SP4N-LAPOR! Provinsi Gorontalo tahun 2023-2024, terdapat 38 aduan pada tahun 2023 yang semua statusnya sudah selesai. Namun Kepala Dinas Kominfotik menegaskan bahwa status 'selesai' tidak cukup. Apa yang beliau maksud?",
    opsi: { A: "Aduan harus tuntas, bukan sekadar selesai secara administratif", B: "Aduan harus dipublikasikan ke media", C: "Aduan harus dibalas dengan surat resmi", D: "Aduan harus dinaikkan ke tingkat provinsi", E: "Aduan harus ditutup dalam 3 hari" },
    bobot: { A: 5, B: 2, C: 3, D: 2, E: 2 }, kunci: "A",
    pembahasan: "Prinsip 'tuntas, bukan sekadar selesai' menekankan bahwa masalah pengadu harus benar-benar terselesaikan substansial."
  },
  {
    id: 8, bagian: "A",
    pertanyaan: "Admin Koordinator SP4N-LAPOR! dilarang untuk… (Pilihlah larangan yang paling krusial)",
    opsi: { A: "Membalas pengaduan dengan cepat", B: "Menyebarluaskan identitas pengadu", C: "Meneruskan pengaduan ke unit terkait", D: "Melakukan verifikasi data", E: "Menindaklanjuti pengaduan substantif" },
    bobot: { A: 1, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Kerahasiaan identitas pengadu adalah kewajiban mutlak admin sesuai PermenPAN-RB No. 5/2025."
  },
  {
    id: 9, bagian: "A",
    pertanyaan: "Anda mendapat laporan masyarakat melalui SP4N-LAPOR! yang berisi kritik pedas terhadap pelayanan dinas Anda. Sikap terbaik yang mencerminkan nilai 'Berorientasi Pelayanan' adalah…",
    opsi: { A: "Menghapus laporan karena dianggap tidak sopan", B: "Membiarkan laporan tanpa tindak lanjut", C: "Mempelajari laporan sebagai bahan perbaikan pelayanan dan merespons dengan profesional", D: "Membalas kritik dengan nada yang sama", E: "Meneruskan laporan ke pimpinan tanpa analisis" },
    bobot: { A: 1, B: 1, C: 5, D: 1, E: 3 }, kunci: "C",
    pembahasan: "Nilai Berorientasi Pelayanan: kritik dijadikan bahan perbaikan, direspons profesional."
  },
  {
    id: 10, bagian: "A",
    pertanyaan: "Dalam sosialisasi PermenPAN-RB Nomor 5 Tahun 2025, disebutkan adanya perubahan regulasi dari PermenPAN-RB sebelumnya. Regulasi yang digantikan adalah…",
    opsi: { A: "PermenPAN-RB Nomor 62 Tahun 2018", B: "PermenPAN-RB Nomor 30 Tahun 2019", C: "PermenPAN-RB Nomor 45 Tahun 2020", D: "PermenPAN-RB Nomor 12 Tahun 2021", E: "PermenPAN-RB Nomor 8 Tahun 2022" },
    bobot: { A: 5, B: 2, C: 2, D: 2, E: 3 }, kunci: "A",
    pembahasan: "PermenPAN-RB No. 5/2025 menggantikan PermenPAN-RB No. 62/2018 tentang pedoman SP4N-LAPOR!."
  },
  {
    id: 11, bagian: "A",
    pertanyaan: "Pimpinan instansi memberikan sanksi teguran tertulis kepada admin pengaduan karena melakukan pelanggaran. Sanksi tersebut merupakan bentuk penerapan dari…",
    opsi: { A: "UU ITE", B: "UU Keterbukaan Informasi Publik", C: "Ketentuan perundang-undangan yang berlaku bagi pengelola pengaduan", D: "UU Administrasi Pemerintahan", E: "Peraturan Menteri Keuangan" },
    bobot: { A: 2, B: 2, C: 5, D: 3, E: 2 }, kunci: "C",
    pembahasan: "Sanksi pengelola pengaduan diberikan sesuai ketentuan perundang-undangan yang berlaku bagi mereka."
  },
  {
    id: 12, bagian: "A",
    pertanyaan: "KLH/BPLH menerima 285 pengaduan selama April-September 2025, namun tingkat responsnya masih di bawah 50 persen. Untuk meningkatkan responsivitas, langkah paling strategis yang harus dilakukan adalah…",
    opsi: { A: "Menambah jumlah admin", B: "Memangkas prosedur verifikasi yang memakan waktu dan mengalihkan langsung ke unit teknis", C: "Memperpanjang batas waktu respons", D: "Menutup sementara kanal pengaduan", E: "Mengalihkan semua pengaduan ke layanan berbayar" },
    bobot: { A: 3, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Sesuai arahan Wamen LH: pangkas bottleneck verifikasi berlapis, alihkan langsung ke unit teknis."
  },
  {
    id: 13, bagian: "A",
    pertanyaan: "Dalam evaluasi implementasi SP4N-LAPOR!, ditemukan bahwa nilai implementasi mencapai rentang 4,2 sampai 4,7 (skala 1-5) dengan dominasi skor 'sangat setuju'. Namun tetap ada hambatan. Hambatan teknis apa yang menjadi perhatian utama menurut hasil identifikasi?",
    opsi: { A: "Kelebihan server", B: "Keterlambatan notifikasi dan ketidaktersediaan PIC di beberapa unit", C: "Terlalu banyak fitur yang membingungkan", D: "Biaya operasional yang terlalu murah", E: "Aplikasi terlalu cepat merespons" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Hambatan utama implementasi: keterlambatan notifikasi & PIC tidak tersedia di sebagian unit kerja."
  },
  {
    id: 14, bagian: "A",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda melihat ada informasi pengadu yang bisa dimanfaatkan untuk kepentingan pribadi. Tindakan yang paling mencerminkan integritas adalah…",
    opsi: { A: "Memanfaatkan informasi tersebut secara diam-diam", B: "Menyimpan informasi untuk keperluan yang tidak jelas", C: "Membagikan ke kolega terpercaya", D: "Menjaga kerahasiaan informasi pengadu sesuai kewajiban sebagai admin", E: "Menjual informasi ke pihak ketiga" },
    bobot: { A: 1, B: 1, C: 1, D: 5, E: 1 }, kunci: "D",
    pembahasan: "Integritas = menjaga kerahasiaan informasi pengadu, sesuai kewajiban admin."
  },
  {
    id: 15, bagian: "A",
    pertanyaan: "Prinsip 'no wrong door policy' dalam pengelolaan pengaduan pelayanan publik berarti…",
    opsi: { A: "Setiap pengaduan harus melalui pintu yang sama", B: "Setiap pintu kantor harus dilengkapi kotak saran", C: "Masyarakat dapat menyampaikan pengaduan melalui berbagai kanal dan tetap akan ditindaklanjuti", D: "Hanya ada satu kanal pengaduan resmi", E: "Pintu kantor harus selalu terbuka" },
    bobot: { A: 2, B: 1, C: 5, D: 2, E: 1 }, kunci: "C",
    pembahasan: "No wrong door policy: melalui kanal apa pun, pengaduan tetap masuk dan ditindaklanjuti."
  },
  {
    id: 16, bagian: "A",
    pertanyaan: "Perubahan dari PermenPAN-RB Nomor 6 Tahun 2023 ke PermenPAN-RB Nomor 5 Tahun 2025 bertujuan untuk…",
    opsi: { A: "Mempersulit masyarakat dalam mengadu", B: "Mengurangi jumlah pengaduan yang masuk", C: "Memperkuat pemanfaatan teknologi informasi dan meningkatkan kualitas respons tindak lanjut", D: "Menghapus sistem pengaduan nasional", E: "Mengganti nama LAPOR! menjadi sistem baru" },
    bobot: { A: 1, B: 1, C: 5, D: 1, E: 2 }, kunci: "C",
    pembahasan: "Tujuan utama revisi: penguatan TI & peningkatan kualitas tindak lanjut."
  },
  {
    id: 17, bagian: "A",
    pertanyaan: "Tantangan seperti rotasi admin, rendahnya pemanfaatan data, hingga belum optimalnya SOP pengaduan menjadi catatan penting. Perbaikan paling mendasar yang harus dilakukan pimpinan adalah…",
    opsi: { A: "Mengganti semua admin setiap bulan", B: "Menyusun dan menetapkan SOP pengaduan yang baku serta memastikan pelatihan berkala", C: "Menambah anggaran untuk insentif admin", D: "Membatasi jumlah pengaduan yang masuk", E: "Menyerahkan semua pengaduan ke pihak ketiga" },
    bobot: { A: 2, B: 5, C: 3, D: 1, E: 2 }, kunci: "B",
    pembahasan: "SOP baku + pelatihan berkala = solusi sistemik untuk semua tantangan tersebut."
  },
  {
    id: 18, bagian: "A",
    pertanyaan: "Dalam analisis berdasarkan indikator William N. Dunn terhadap implementasi SP4N-LAPOR!, aspek yang masih perlu diperkuat mencakup…",
    opsi: { A: "Hanya efektivitas", B: "Efektivitas, efisiensi, kecukupan, pemerataan, responsivitas, dan ketepatan tindak lanjut", C: "Hanya efisiensi", D: "Hanya pemerataan", E: "Hanya responsivitas" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "6 kriteria Dunn (efektivitas, efisiensi, kecukupan, pemerataan, responsivitas, ketepatan) semuanya relevan untuk evaluasi kebijakan publik."
  },
  {
    id: 19, bagian: "A",
    pertanyaan: "Pimpinan instansi menegaskan pentingnya komitmen pimpinan dalam keberhasilan SP4N-LAPOR!. Pernyataan ini menunjukkan bahwa…",
    opsi: { A: "Sistem dapat berjalan tanpa dukungan pimpinan", B: "Kunci keberhasilan SP4N-LAPOR! terletak pada komitmen aktif pimpinan untuk menindaklanjuti laporan", C: "Admin lebih penting daripada pimpinan", D: "Masyarakat tidak perlu tahu tentang sistem", E: "Anggaran adalah satu-satunya faktor penentu" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Top-down commitment dari pimpinan adalah kunci keberhasilan reformasi birokrasi."
  },
  {
    id: 20, bagian: "A",
    pertanyaan: "Sebuah pengaduan masyarakat telah ditindaklanjuti, tetapi masyarakat melaporkan ulang karena belum puas. Langkah terbaik yang harus dilakukan sebagai admin pengaduan adalah…",
    opsi: { A: "Menutup pengaduan karena sudah direspons", B: "Mengabaikan pengaduan ulang", C: "Melakukan evaluasi dan verifikasi ulang, jika perlu melibatkan pengawas eksternal", D: "Menyalahkan masyarakat yang terlalu banyak menuntut", E: "Meneruskan tanpa verifikasi" },
    bobot: { A: 1, B: 1, C: 5, D: 1, E: 2 }, kunci: "C",
    pembahasan: "Prinsip tuntas: evaluasi ulang & libatkan pengawas eksternal bila perlu."
  },
  {
    id: 21, bagian: "A",
    pertanyaan: "KLH/BPLH berhasil memangkas proses perizinan AMDAL dari 168 hari (2024) menjadi 51 hari (2025). Prestasi ini menunjukkan keberhasilan dalam implementasi nilai ASN BerAKHLAK, terutama nilai…",
    opsi: { A: "Harmonis", B: "Adaptif dan Kolaboratif", C: "Loyal", D: "Berorientasi Pelayanan dan Akuntabel", E: "Adaptif" },
    bobot: { A: 2, B: 3, C: 2, D: 5, E: 3 }, kunci: "D",
    pembahasan: "Percepatan layanan publik = wujud Berorientasi Pelayanan + Akuntabel (efisiensi yang dapat dipertanggungjawabkan)."
  },
  {
    id: 22, bagian: "A",
    pertanyaan: "Dalam situasi darurat, ada pengaduan masyarakat yang sangat kritis dan harus segera ditindaklanjuti di luar jam kerja. Tindakan terbaik sebagai admin pengaduan adalah…",
    opsi: { A: "Menunggu jam kerja berikutnya", B: "Merespons secara cepat meskipun di luar jam kerja sesuai kewenangan dan protokol darurat", C: "Meminta maaf dan menunda", D: "Mengalihkan ke pihak lain tanpa informasi", E: "Menghapus pengaduan" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Respons cepat sesuai protokol darurat = wujud Berorientasi Pelayanan dalam kondisi kritis."
  },
  {
    id: 23, bagian: "A",
    pertanyaan: "SP4N-LAPOR! menjadi indikator utama dalam proses penilaian pelayanan publik dan reformasi birokrasi. Pernyataan berikut yang PALING TEPAT adalah…",
    opsi: { A: "SP4N-LAPOR! hanya alat pengaduan biasa", B: "Keberhasilan pengelolaan pengaduan mencerminkan kualitas reformasi birokrasi suatu instansi", C: "SP4N-LAPOR! tidak terkait dengan kinerja instansi", D: "Indikator penilaian hanya berdasarkan jumlah pengaduan", E: "SP4N-LAPOR! menggantikan seluruh sistem pelayanan" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "SP4N-LAPOR! = cermin RB instansi karena mengukur responsivitas & akuntabilitas."
  },
  {
    id: 24, bagian: "A",
    pertanyaan: "Pemerintah Provinsi Jawa Timur mencatat tiga daerah dengan tindak lanjut pengaduan 100 persen. Berdasarkan data 1 Januari 2023 - 31 Mei 2024, kota dengan total aduan tertinggi (3.074 pengaduan) adalah…",
    opsi: { A: "Kota Surabaya", B: "Kota Malang", C: "Kota Mojokerto", D: "Kabupaten Gresik", E: "Kabupaten Sidoarjo" },
    bobot: { A: 2, B: 5, C: 2, D: 3, E: 2 }, kunci: "B",
    pembahasan: "Berdasarkan data KemenPAN-RB & Pemprov Jatim, Kota Malang mencatat total aduan tertinggi 3.074 dengan tindak lanjut 100%."
  },
  {
    id: 25, bagian: "A",
    pertanyaan: "Anda adalah admin koordinator. Sebuah pengaduan telah diverifikasi dan diteruskan ke unit terkait, tetapi unit tersebut tidak merespons hingga melewati batas waktu. Langkah paling tepat adalah…",
    opsi: { A: "Menunggu lebih lama", B: "Melaporkan ke pimpinan untuk tindakan koordinasi lintas unit dan pemantauan dashboard", C: "Menutup pengaduan sendiri", D: "Mengembalikan ke pengadu", E: "Meneruskan ke unit lain tanpa koordinasi" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 3 }, kunci: "B",
    pembahasan: "Eskalasi ke pimpinan + monitoring dashboard = mekanisme paling akuntabel."
  },
  {
    id: 26, bagian: "A",
    pertanyaan: "Dalam sosialisasi SP4N-LAPOR! di Kanwil Kemenkum Riau, ditekankan bahwa transformasi pengelolaan pengaduan bertujuan menghadirkan layanan yang…",
    opsi: { A: "Lambat tapi akurat", B: "Mahal tapi berkualitas", C: "Responsif, transparan, dan berorientasi pada kebutuhan masyarakat", D: "Eksklusif untuk kalangan tertentu", E: "Manual untuk menghindari teknologi" },
    bobot: { A: 1, B: 2, C: 5, D: 1, E: 1 }, kunci: "C",
    pembahasan: "Tiga pilar transformasi pelayanan: responsif, transparan, berorientasi masyarakat."
  },
  {
    id: 27, bagian: "A",
    pertanyaan: "KemenPAN-RB menekankan bahwa pengaduan harus dijadikan sebagai dasar perbaikan pelayanan publik. Implementasi terbaik dari prinsip ini adalah…",
    opsi: { A: "Mengumpulkan pengaduan tanpa tindak lanjut", B: "Menganalisis pola pengaduan dan menyusun rencana aksi perbaikan berkelanjutan", C: "Menyimpan pengaduan sebagai arsip", D: "Membalas setiap pengaduan dengan template yang sama", E: "Menghapus pengaduan setelah dibaca" },
    bobot: { A: 1, B: 5, C: 2, D: 3, E: 1 }, kunci: "B",
    pembahasan: "Analisis pola + rencana aksi berkelanjutan = continuous improvement."
  },
  {
    id: 28, bagian: "A",
    pertanyaan: "Sebagai admin instansi, Anda menerima pengaduan yang substansinya sudah pernah ditangani sebelumnya oleh unit yang sama. Apa yang harus dilakukan?",
    opsi: { A: "Menutup pengaduan dengan alasan duplikasi", B: "Mengabaikan karena sudah pernah ditangani", C: "Melakukan koordinasi dengan unit terkait untuk memastikan tindak lanjut yang tuntas dan menghubungi pengadu untuk klarifikasi", D: "Meneruskan ke unit lain", E: "Menghapus dari sistem" },
    bobot: { A: 3, B: 1, C: 5, D: 2, E: 1 }, kunci: "C",
    pembahasan: "Pengaduan berulang = sinyal masalah belum tuntas. Koordinasi + klarifikasi pengadu wajib."
  },
  {
    id: 29, bagian: "A",
    pertanyaan: "Dalam proses pengelolaan pengaduan, identitas pengadu harus dilindungi sesuai regulasi. Seorang oknum ASN menyebarluaskan identitas pengadu ke media sosial. Tindakan yang harus diambil pimpinan adalah…",
    opsi: { A: "Membiarkan karena hanya kesalahan kecil", B: "Memberikan teguran lisan ringan", C: "Memberikan sanksi sesuai ketentuan perundang-undangan, mulai dari teguran hingga pemberhentian", D: "Memindahkan ke unit lain tanpa sanksi", E: "Menutup kasus tanpa tindakan" },
    bobot: { A: 1, B: 2, C: 5, D: 2, E: 1 }, kunci: "C",
    pembahasan: "Penyebaran identitas pengadu = pelanggaran berat, sanksi sesuai PP 94/2021 hingga pemberhentian."
  },
  {
    id: 30, bagian: "A",
    pertanyaan: "Kepala Kanwil Kemenkum Sumsel menegaskan komitmen untuk terus meningkatkan kualitas penanganan pengaduan dengan tiga aspek utama berikut, KECUALI…",
    opsi: { A: "Memperkuat koordinasi", B: "Meningkatkan kapasitas SDM", C: "Memastikan setiap laporan ditangani cepat dan tepat", D: "Menambah jumlah pengaduan dengan sengaja", E: "Meningkatkan akuntabilitas pelayanan publik" },
    bobot: { A: 4, B: 4, C: 4, D: 5, E: 4 }, kunci: "D",
    pembahasan: "Menambah pengaduan dengan sengaja jelas bukan tujuan reformasi pelayanan."
  },
  {
    id: 31, bagian: "A",
    pertanyaan: "PermenPAN-RB Nomor 5 Tahun 2025 tentang SP4N-LAPOR! memiliki batas waktu maksimal tindak lanjut 14 hari untuk kategori pengaduan…",
    opsi: { A: "Yang bersifat permintaan informasi", B: "Yang bersifat normatif", C: "Yang tidak bersifat pengawasan dan pemeriksaan lapangan", D: "Yang mengandung unsur kriminal", E: "Yang melibatkan menteri" },
    bobot: { A: 2, B: 3, C: 5, D: 2, E: 1 }, kunci: "C",
    pembahasan: "Kategori 14 hari = pengaduan yang TIDAK memerlukan pengawasan/pemeriksaan lapangan namun substantif."
  },
  {
    id: 32, bagian: "A",
    pertanyaan: "Kegiatan monitoring dan evaluasi (monev) SP4N-LAPOR! di Provinsi Gorontalo pada tahun 2024 diikuti oleh Dinas Kominfotik, Inspektorat, dan Biro Organisasi serta kabupaten/kota. Keikutsertaan Inspektorat dalam monev menunjukkan…",
    opsi: { A: "SP4N-LAPOR! tidak memerlukan pengawasan", B: "Peran pengawasan internal penting untuk memastikan efektivitas sistem", C: "Inspektorat akan menggantikan fungsi admin", D: "Semua pengaduan harus melalui Inspektorat", E: "Inspektorat tidak relevan dengan SP4N-LAPOR!" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Inspektorat = APIP yang mengawasi sistem internal untuk memastikan efektivitas SP4N-LAPOR!."
  },
  {
    id: 33, bagian: "A",
    pertanyaan: "Dalam menangani pengaduan yang memerlukan verifikasi lapangan, admin harus memastikan adanya bukti fisik yang valid. Namun daerah tujuan verifikasi sulit dijangkau. Strategi terbaik adalah…",
    opsi: { A: "Membatalkan proses verifikasi", B: "Mengganti dengan verifikasi dokumen saja", C: "Menggunakan teknologi seperti drone atau video call untuk verifikasi jarak jauh dengan tetap memperhatikan standar keabsahan", D: "Menunggu sampai akses mudah", E: "Menyerahkan ke pihak ketiga tanpa pengawasan" },
    bobot: { A: 1, B: 2, C: 5, D: 1, E: 3 }, kunci: "C",
    pembahasan: "Adaptif: teknologi (drone/video call) memungkinkan verifikasi tetap valid di daerah sulit."
  },
  {
    id: 34, bagian: "A",
    pertanyaan: "Mayoritas instansi pemerintah masih menghadapi hambatan struktural dalam implementasi SP4N-LAPOR!. Hambatan yang paling mendesak untuk dibenahi adalah…",
    opsi: { A: "Keterbatasan fitur aplikasi dan koordinasi lintas unit yang masih manual", B: "Terlalu banyak admin", C: "Terlalu sedikit pengaduan", D: "Masyarakat tidak mau mengadu", E: "Anggaran berlebih" },
    bobot: { A: 5, B: 2, C: 1, D: 2, E: 1 }, kunci: "A",
    pembahasan: "Hambatan struktural utama: fitur aplikasi & koordinasi lintas unit masih manual."
  },
  {
    id: 35, bagian: "A",
    pertanyaan: "Pejabat penghubung SP4N-LAPOR! menerima pengaduan dengan bukti yang kurang jelas. Langkah terbaik untuk mengklarifikasi adalah…",
    opsi: { A: "Menolak pengaduan", B: "Menghubungi pengadu untuk meminta klarifikasi dan kelengkapan data", C: "Meneruskan tanpa verifikasi", D: "Memutuskan sendiri kebenaran pengaduan", E: "Menutup pengaduan" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Klarifikasi langsung ke pengadu = praktik terbaik verifikasi data."
  },
  // ====== BAGIAN B: SEKDIN (36-60) ======
  {
    id: 36, bagian: "B",
    pertanyaan: "Seorang Sekretaris Dinas memiliki tugas pokok membantu Kepala Dinas dalam berbagai bidang. Berikut ini yang BUKAN merupakan fungsi utama Sekretaris Dinas adalah…",
    opsi: { A: "Menyelenggarakan ketatausahaan dan administrasi kepegawaian", B: "Mengelola administrasi keuangan dan urusan umum", C: "Menentukan kebijakan teknis secara independen tanpa koordinasi dengan Kepala Dinas", D: "Memberikan pelayanan administrasi kepada semua unit kerja", E: "Melakukan monitoring, evaluasi dan penyusunan laporan" },
    bobot: { A: 4, B: 4, C: 5, D: 4, E: 4 }, kunci: "C",
    pembahasan: "Sekdin TIDAK boleh menentukan kebijakan teknis secara independen; semua harus dikoordinasikan dgn Kepala Dinas."
  },
  {
    id: 37, bagian: "B",
    pertanyaan: "Sub Bagian Umum dan Kepegawaian di lingkungan Sekretariat Dinas bertanggung jawab atas urusan berikut, KECUALI…",
    opsi: { A: "Surat menyurat dan kearsipan", B: "Urusan rumah tangga dan keprotokolan", C: "Penyusunan laporan keuangan daerah", D: "Administrasi kepegawaian", E: "Pengelolaan barang milik daerah" },
    bobot: { A: 4, B: 4, C: 5, D: 4, E: 4 }, kunci: "C",
    pembahasan: "Laporan keuangan daerah adalah ranah Sub Bagian Keuangan, bukan Sub Bagian Umum & Kepegawaian."
  },
  {
    id: 38, bagian: "B",
    pertanyaan: "Sub Bagian Keuangan Sekretariat Dinas bertugas menyiapkan Surat Perintah Membayar (SPM). Jenis SPM untuk belanja yang langsung dibayarkan ke penerima disebut…",
    opsi: { A: "SPM UP", B: "SPM GU", C: "SPM TU", D: "SPM LS", E: "SPM Nihil" },
    bobot: { A: 2, B: 2, C: 2, D: 5, E: 2 }, kunci: "D",
    pembahasan: "SPM-LS (Langsung) = pembayaran langsung ke penerima (pihak ketiga/gaji). UP/GU/TU = uang persediaan."
  },
  {
    id: 39, bagian: "B",
    pertanyaan: "Sekretaris Dinas berfungsi sebagai koordinator penyusunan program dan anggaran. Dalam rapat koordinasi, ada perbedaan pendapat antar bidang mengenai alokasi anggaran. Tindakan Sekretaris yang paling efektif adalah…",
    opsi: { A: "Memutuskan sendiri sesuai keinginan pribadi", B: "Mengikuti keinginan bidang dengan anggaran terbesar", C: "Menunda rapat tanpa solusi", D: "Memfasilitasi diskusi berbasis data dan prioritas program, kemudian merekomendasikan ke Kepala Dinas", E: "Mengalihkan ke pimpinan tanpa proses mediasi" },
    bobot: { A: 1, B: 2, C: 2, D: 5, E: 3 }, kunci: "D",
    pembahasan: "Mediasi berbasis data + rekomendasi ke Kepala Dinas = peran koordinator yang efektif."
  },
  {
    id: 40, bagian: "B",
    pertanyaan: "Dalam mengelola administrasi kepegawaian, Sekretaris Dinas harus memastikan penerapan sistem merit. Sistem merit berarti…",
    opsi: { A: "Promosi berdasarkan kedekatan dengan atasan", B: "Promosi berdasarkan kinerja, kompetensi, dan kualifikasi", C: "Promosi berdasarkan senioritas mutlak", D: "Promosi berdasarkan suku/agama", E: "Promosi berdasarkan undian" },
    bobot: { A: 1, B: 5, C: 3, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Sistem merit (UU 20/2023): kinerja, kompetensi, kualifikasi — bukan kedekatan/senioritas mutlak."
  },
  {
    id: 41, bagian: "B",
    pertanyaan: "Sekretaris Dinas menerima laporan bahwa salah satu pegawai sering terlambat dan kinerjanya menurun. Langkah terbaik yang harus diambil Sekretaris adalah…",
    opsi: { A: "Langsung memberikan surat peringatan", B: "Memanggil pegawai untuk pembinaan dan mencari penyebab masalah secara profesional", C: "Mengabaikan karena bukan wewenang langsung", D: "Memecat tanpa klarifikasi", E: "Menurunkan pangkat tanpa proses" },
    bobot: { A: 3, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Pembinaan dengan klarifikasi akar masalah = pendekatan SDM profesional."
  },
  {
    id: 42, bagian: "B",
    pertanyaan: "Sub Koordinator Penyusunan Program dan Anggaran memiliki tugas menyiapkan bahan monitoring dan evaluasi program. Indikator keberhasilan tugas ini yang paling tepat adalah…",
    opsi: { A: "Semakin tebal laporan yang dihasilkan", B: "Semakin banyak rekomendasi perbaikan yang diimplementasikan untuk meningkatkan efektivitas program", C: "Semakin sering rapat koordinasi diadakan", D: "Semakin besar anggaran yang dikelola", E: "Semakin banyak pegawai yang dilibatkan" },
    bobot: { A: 2, B: 5, C: 3, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Output monev: rekomendasi yang diimplementasikan = outcome nyata, bukan sekadar dokumen."
  },
  {
    id: 43, bagian: "B",
    pertanyaan: "Sekretaris Dinas diminta untuk menyiapkan laporan kinerja triwulanan. Dalam penyusunannya, data dari beberapa bidang tidak lengkap. Tindakan Sekretaris yang paling profesional adalah…",
    opsi: { A: "Mengisi data secara asal-asalan", B: "Melaporkan dengan data yang tidak lengkap dan mencantumkan catatan keterbatasan data", C: "Menunda pelaporan tanpa batas waktu", D: "Memalsukan data agar laporan terlihat baik", E: "Menyalahkan bidang yang bersangkutan di laporan" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 3 }, kunci: "B",
    pembahasan: "Transparansi: laporkan apa adanya + disclaimer keterbatasan data = wujud akuntabilitas."
  },
  {
    id: 44, bagian: "B",
    pertanyaan: "Fungsi Sekretariat meliputi pengelolaan hubungan masyarakat (humas) dan protokol. Ketika ada kunjungan tamu penting dari instansi pusat, Sekretaris harus memastikan…",
    opsi: { A: "Tamu dilayani sesuai standar protokol yang berlaku tanpa berlebihan", B: "Tamu diabaikan karena terlalu sibuk", C: "Mengatur penerimaan yang berlebihan dan menghamburkan anggaran", D: "Menolak kunjungan dengan alasan kesibukan", E: "Menyerahkan sepenuhnya ke staf tanpa koordinasi" },
    bobot: { A: 5, B: 1, C: 2, D: 2, E: 2 }, kunci: "A",
    pembahasan: "Protokol sesuai standar tanpa pemborosan = efisien & sesuai aturan."
  },
  {
    id: 45, bagian: "B",
    pertanyaan: "Sekretaris Dinas memiliki wewenang dalam pengelolaan barang milik negara/daerah. Prinsip pengelolaan aset yang benar adalah…",
    opsi: { A: "Aset dapat digunakan untuk kepentingan pribadi selama tidak merusak", B: "Aset harus dikelola secara akuntabel, transparan, dan efisien untuk kepentingan pelayanan publik", C: "Aset dapat dipinjamkan ke keluarga tanpa prosedur", D: "Aset dapat dijual tanpa persetujuan", E: "Aset boleh diabaikan karena milik negara" },
    bobot: { A: 1, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "PP 27/2014 jo. PP 28/2020: pengelolaan BMN/D wajib akuntabel, transparan, efisien."
  },
  {
    id: 46, bagian: "B",
    pertanyaan: "Dalam pelaksanaan koordinasi penyelesaian masalah hukum non-yustisia di bidang kepegawaian, Sekretaris Dinas harus…",
    opsi: { A: "Menyelesaikan sendiri tanpa konsultasi", B: "Melibatkan bagian hukum dan konsultasi dengan instansi terkait", C: "Mengabaikan masalah hukum", D: "Memutuskan berdasarkan sentimen pribadi", E: "Menyerahkan ke luar tanpa koordinasi internal" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Masalah hukum kepegawaian harus melibatkan biro hukum & konsultasi instansi terkait."
  },
  {
    id: 47, bagian: "B",
    pertanyaan: "Sekretaris Dinas diminta membantu Kepala Dinas dalam menyusun rencana strategis (Renstra). Kontribusi yang paling berharga dari Sekretaris adalah…",
    opsi: { A: "Menyusun rencana berdasarkan keinginan pribadi", B: "Menyediakan data dan analisis dari hasil monitoring dan evaluasi kinerja sebelumnya", C: "Menyalin Renstra tahun lalu tanpa perubahan", D: "Membuat rencana yang tidak realistis", E: "Menyerahkan sepenuhnya ke konsultan" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Renstra berbasis bukti (evidence-based) dari data monev = perencanaan berkualitas."
  },
  {
    id: 48, bagian: "B",
    pertanyaan: "Fungsi Sekretariat dalam pelaksanaan pelayanan teknis administrasi kepada semua unit organisasi di lingkungan dinas mencakup…",
    opsi: { A: "Hanya melayani unit tertentu saja", B: "Memberikan pelayanan yang setara dan profesional kepada seluruh unit tanpa diskriminasi", C: "Melayani jika diminta dengan baik", D: "Melayani hanya unit yang disukai Sekretaris", E: "Tidak perlu melayani karena bukan tugas utama" },
    bobot: { A: 2, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Pelayanan setara tanpa diskriminasi = prinsip dasar pelayanan administrasi internal."
  },
  {
    id: 49, bagian: "B",
    pertanyaan: "Sub Bagian Umum dan Kepegawaian bertugas menyusun rencana kebutuhan barang dan operasional kantor. Prinsip penyusunan yang benar adalah…",
    opsi: { A: "Membeli barang sebanyak-banyaknya", B: "Menyusun berdasarkan kebutuhan riil, skala prioritas, dan efisiensi anggaran", C: "Membeli barang termahal", D: "Membeli barang hanya untuk kepentingan pribadi pejabat", E: "Tidak perlu perencanaan" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "RKBMD/RKBMN berbasis kebutuhan riil, prioritas, dan efisiensi anggaran."
  },
  {
    id: 50, bagian: "B",
    pertanyaan: "Sekretaris Dinas bertanggung jawab atas pengelolaan kearsipan dan perpustakaan. Kebijakan yang paling tepat terkait kearsipan adalah…",
    opsi: { A: "Arsip boleh dibuang setelah 1 bulan", B: "Arsip harus dikelola dengan sistem kearsipan yang baik sesuai peraturan perundang-undangan", C: "Arsip hanya untuk kepentingan Sekretaris", D: "Arsip tidak penting untuk dikelola", E: "Arsip boleh dipinjamkan tanpa pencatatan" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "UU 43/2009 tentang Kearsipan: arsip wajib dikelola sistematis sesuai jadwal retensi."
  },
  {
    id: 51, bagian: "B",
    pertanyaan: "Dalam melakukan verifikasi Surat Pertanggungjawaban (SPJ), Sub Bagian Keuangan menemukan ketidaksesuaian antara bukti dan laporan. Tindakan yang harus diambil adalah…",
    opsi: { A: "Mengesahkan SPJ tanpa perubahan", B: "Mengembalikan SPJ untuk diperbaiki dan memberikan catatan ketidaksesuaian", C: "Menyembunyikan temuan", D: "Memecat pegawai yang bersangkutan langsung", E: "Memalsukan bukti agar sesuai" },
    bobot: { A: 2, B: 5, C: 1, D: 3, E: 1 }, kunci: "B",
    pembahasan: "Verifikasi SPJ = kontrol internal. Wajib dikembalikan utk perbaikan dengan catatan."
  },
  {
    id: 52, bagian: "B",
    pertanyaan: "Sekretaris Dinas diangkat melalui proses yang kompetitif dan berdasarkan kualifikasi. Hal ini sesuai dengan prinsip…",
    opsi: { A: "Nepotisme", B: "Sistem merit dalam manajemen ASN", C: "Kolusi", D: "Kekeluargaan berlebihan", E: "Favoritisme" },
    bobot: { A: 1, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Open bidding JPT = wujud sistem merit (UU 20/2023)."
  },
  {
    id: 53, bagian: "B",
    pertanyaan: "Dalam mengoordinasikan pelaksanaan tugas bidang-bidang pada dinas, Sekretaris menghadapi situasi di mana dua bidang berselisih terkait batasan tugas. Tindakan terbaik Sekretaris adalah…",
    opsi: { A: "Membiarkan perselisihan berlanjut", B: "Memfasilitasi dialog dan klarifikasi tupoksi masing-masing bidang secara tertulis", C: "Memihak salah satu bidang", D: "Menyuruh kedua bidang menyelesaikan sendiri", E: "Menggabungkan kedua bidang tanpa kejelasan" },
    bobot: { A: 1, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Mediasi + klarifikasi tupoksi tertulis = cara koordinator profesional."
  },
  {
    id: 54, bagian: "B",
    pertanyaan: "Sekretaris Dinas mendapatkan informasi bahwa salah satu sub bagian melakukan pungutan liar dalam pelayanan administrasi. Tindakan yang paling tepat adalah…",
    opsi: { A: "Menutup mata karena kolega", B: "Melakukan investigasi internal dan jika terbukti melaporkan ke atasan/inspektorat untuk penindakan sesuai aturan", C: "Memberikan teguran lisan tanpa bukti", D: "Membiarkan karena sudah biasa", E: "Memecat langsung tanpa proses" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 3 }, kunci: "B",
    pembahasan: "Investigasi internal + laporan APIP = jalur penegakan disiplin sesuai PP 94/2021."
  },
  {
    id: 55, bagian: "B",
    pertanyaan: "Sekretaris diminta untuk menyusun laporan tahunan yang akan dipresentasikan ke DPRD. Komponen penting yang harus ada dalam laporan tersebut adalah…",
    opsi: { A: "Hanya daftar kegiatan", B: "Realisasi anggaran, capaian kinerja, dan rekomendasi perbaikan", C: "Foto-foto kegiatan tanpa data", D: "Klaim keberhasilan tanpa bukti", E: "Hanya laporan keuangan" },
    bobot: { A: 2, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Laporan ke DPRD wajib komprehensif: anggaran, kinerja, rekomendasi."
  },
  {
    id: 56, bagian: "B",
    pertanyaan: "Sekretariat bertugas melakukan monitoring dan evaluasi organisasi dan tata laksana. Ketika ditemukan prosedur yang menghambat efisiensi pelayanan, Sekretaris harus…",
    opsi: { A: "Membiarkan karena sudah prosedur baku", B: "Mengusulkan perbaikan dan penyederhanaan prosedur kepada Kepala Dinas", C: "Menghapus prosedur tanpa kajian", D: "Menambah prosedur baru agar lebih rumit", E: "Mengabaikan temuan" },
    bobot: { A: 2, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Penyederhanaan birokrasi melalui usulan formal ke pimpinan = jalur perbaikan yang sah."
  },
  {
    id: 57, bagian: "B",
    pertanyaan: "Sub Koordinator Penyusunan Program dan Anggaran harus menyusun laporan realisasi anggaran. Data dari bidang belum lengkap dan deadline sudah dekat. Sikap yang tepat adalah…",
    opsi: { A: "Memaksakan laporan dengan data palsu", B: "Berkoordinasi dengan bidang untuk mempercepat pengiriman data, sambil menyusun laporan sementara dengan disclaimer", C: "Menunda laporan tanpa batas waktu", D: "Menyalahkan bidang di depan umum", E: "Menyerahkan laporan kosong" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Koordinasi aktif + laporan sementara dengan disclaimer = profesional & tepat waktu."
  },
  {
    id: 58, bagian: "B",
    pertanyaan: "Dalam rangka mendukung good governance, Sekretaris Dinas harus memastikan tersedianya layanan informasi publik. Hal ini sesuai dengan UU…",
    opsi: { A: "UU No. 14 Tahun 2008 tentang Keterbukaan Informasi Publik", B: "UU No. 11 Tahun 2008 tentang ITE", C: "UU No. 5 Tahun 2014 tentang ASN", D: "UU No. 23 Tahun 2014 tentang Pemerintahan Daerah", E: "UU No. 30 Tahun 2014 tentang Administrasi Pemerintahan" },
    bobot: { A: 5, B: 2, C: 3, D: 4, E: 3 }, kunci: "A",
    pembahasan: "UU 14/2008 KIP mengatur kewajiban Badan Publik menyediakan informasi publik."
  },
  {
    id: 59, bagian: "B",
    pertanyaan: "Sekretaris Dinas menerima instruksi dari Kepala Dinas yang secara teknis sulit diimplementasikan karena keterbatasan sumber daya. Tindakan terbaik Sekretaris adalah…",
    opsi: { A: "Melaksanakan instruksi tanpa mempertimbangkan konsekuensi", B: "Menolak instruksi secara langsung", C: "Memberikan masukan konstruktif disertai analisis kelayakan dan alternatif solusi", D: "Mengabaikan instruksi", E: "Melaporkan ke atasan di atas Kepala Dinas" },
    bobot: { A: 3, B: 2, C: 5, D: 1, E: 2 }, kunci: "C",
    pembahasan: "Masukan konstruktif + analisis + alternatif = sikap loyal kritis yang profesional."
  },
  {
    id: 60, bagian: "B",
    pertanyaan: "Fungsi Sekretariat dalam pengelolaan barang milik daerah mencakup inventarisasi, pengadaan, perawatan, dan pemeliharaan. Prinsip yang harus dipegang adalah…",
    opsi: { A: "Aset negara dapat digunakan untuk kegiatan pribadi", B: "Aset dikelola secara tertib, efisien, ekonomis, efektif, transparan, dan bertanggung jawab", C: "Aset dapat dijual bebas", D: "Aset dibiarkan rusak", E: "Aset hanya untuk kepentingan pejabat" },
    bobot: { A: 1, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "6 prinsip pengelolaan BMN/D: tertib, efisien, ekonomis, efektif, transparan, bertanggung jawab."
  },
  // ====== BAGIAN C: BERAKHLAK & KODE ETIK (61-90) ======
  {
    id: 61, bagian: "C",
    pertanyaan: "Core Value ASN 'BerAKHLAK' merupakan akronim dari nilai-nilai dasar ASN. Urutan nilai BerAKHLAK yang benar adalah…",
    opsi: { A: "Berakhlak, Kreatif, Loyal, Amanah, Kompeten, Adaptif", B: "Berorientasi Pelayanan, Akuntabel, Kompeten, Harmonis, Loyal, Adaptif, Kolaboratif", C: "Bersih, Efektif, Ramah, Adil, Kreatif, Loyal, Akuntabel", D: "Berintegritas, Kompeten, Loyal, Akuntabel, Harmonis, Adaptif", E: "Berorientasi Pelayanan, Kreatif, Loyal, Amanah, Kolektif" },
    bobot: { A: 2, B: 5, C: 2, D: 3, E: 2 }, kunci: "B",
    pembahasan: "BerAKHLAK = Berorientasi Pelayanan, Akuntabel, Kompeten, Harmonis, Loyal, Adaptif, Kolaboratif (SE MenPANRB 20/2021)."
  },
  {
    id: 62, bagian: "C",
    pertanyaan: "Seorang ASN memberikan pelayanan yang cepat, tepat, dan ramah kepada masyarakat tanpa membedakan latar belakang. Tindakan ini mencerminkan nilai BerAKHLAK yaitu…",
    opsi: { A: "Akuntabel", B: "Kompeten", C: "Berorientasi Pelayanan", D: "Harmonis", E: "Adaptif" },
    bobot: { A: 2, B: 3, C: 5, D: 3, E: 2 }, kunci: "C",
    pembahasan: "Pelayanan cepat-tepat-ramah tanpa diskriminasi = Berorientasi Pelayanan."
  },
  {
    id: 63, bagian: "C",
    pertanyaan: "Seorang ASN bertanggung jawab penuh atas pengelolaan keuangan negara, transparan, dan siap diperiksa kapan saja. Ini mencerminkan nilai…",
    opsi: { A: "Berorientasi Pelayanan", B: "Akuntabel", C: "Kompeten", D: "Loyal", E: "Kolaboratif" },
    bobot: { A: 2, B: 5, C: 3, D: 4, E: 2 }, kunci: "B",
    pembahasan: "Tanggung jawab + transparansi + siap diperiksa = inti nilai Akuntabel."
  },
  {
    id: 64, bagian: "C",
    pertanyaan: "ASN diharuskan menjaga netralitas politik dan tidak terlibat dalam kampanye pemilu. Larangan ini merupakan implementasi dari nilai BerAKHLAK, terutama nilai…",
    opsi: { A: "Akuntabel", B: "Berorientasi Pelayanan", C: "Loyal", D: "Adaptif", E: "Kolaboratif" },
    bobot: { A: 2, B: 3, C: 5, D: 2, E: 2 }, kunci: "C",
    pembahasan: "Netralitas politik = wujud Loyal pada NKRI/Pancasila, bukan parpol."
  },
  {
    id: 65, bagian: "C",
    pertanyaan: "Seorang ASN terus meng-upgrade kemampuan dan pengetahuannya agar tetap relevan dengan perkembangan zaman. Ini mencerminkan nilai…",
    opsi: { A: "Harmonis", B: "Kolaboratif", C: "Akuntabel", D: "Adaptif", E: "Loyal" },
    bobot: { A: 2, B: 3, C: 2, D: 5, E: 2 }, kunci: "D",
    pembahasan: "Upgrade berkelanjutan = nilai Adaptif (terus berinovasi & antusias terhadap perubahan)."
  },
  {
    id: 66, bagian: "C",
    pertanyaan: "Dalam situasi konflik antar pegawai, seorang ASN berusaha menjadi penengah yang baik dan menjaga keharmonisan tim. Tindakan ini mencerminkan nilai…",
    opsi: { A: "Kompeten", B: "Harmonis", C: "Adaptif", D: "Akuntabel", E: "Berorientasi Pelayanan" },
    bobot: { A: 2, B: 5, C: 3, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Penengah konflik & jaga harmoni = nilai Harmonis."
  },
  {
    id: 67, bagian: "C",
    pertanyaan: "Seorang ASN mampu bekerja sama lintas sektor dan lintas unit untuk menyelesaikan masalah kompleks. Ini mencerminkan nilai…",
    opsi: { A: "Akuntabel", B: "Kompeten", C: "Loyal", D: "Kolaboratif", E: "Adaptif" },
    bobot: { A: 2, B: 3, C: 2, D: 5, E: 3 }, kunci: "D",
    pembahasan: "Kerja sama lintas sektor = nilai Kolaboratif (sinergi untuk hasil lebih baik)."
  },
  {
    id: 68, bagian: "C",
    pertanyaan: "Kode etik ASN diatur dalam berbagai regulasi. Undang-Undang yang menjadi landasan utama pengaturan ASN saat ini adalah…",
    opsi: { A: "UU No. 20 Tahun 2023 tentang ASN", B: "UU No. 5 Tahun 2014 tentang ASN", C: "UU No. 30 Tahun 2014 tentang Administrasi Pemerintahan", D: "UU No. 14 Tahun 2008 tentang Keterbukaan Informasi Publik", E: "UU No. 11 Tahun 2008 tentang ITE" },
    bobot: { A: 5, B: 4, C: 3, D: 2, E: 2 }, kunci: "A",
    pembahasan: "UU No. 20/2023 menggantikan UU No. 5/2014 sebagai landasan utama manajemen ASN."
  },
  {
    id: 69, bagian: "C",
    pertanyaan: "Sanksi bagi ASN yang melanggar disiplin berat seperti korupsi dapat berupa…",
    opsi: { A: "Teguran lisan", B: "Penundaan kenaikan gaji", C: "Pemberhentian dengan hormat", D: "Pemberhentian tidak hormat", E: "Pemindahan tugas" },
    bobot: { A: 1, B: 2, C: 2, D: 5, E: 2 }, kunci: "D",
    pembahasan: "PP 94/2021: sanksi disiplin berat untuk korupsi = pemberhentian tidak dengan hormat."
  },
  {
    id: 70, bagian: "C",
    pertanyaan: "Dalam PermenPANRB Nomor 6 Tahun 2022 tentang Pengelolaan Kinerja Pegawai ASN, penilaian kinerja harus berbasis pada…",
    opsi: { A: "Kedekatan dengan atasan", B: "Capaian target dan perilaku kerja sesuai core values", C: "Masa kerja", D: "Jumlah jam lembur", E: "Pendidikan terakhir" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "PermenPANRB 6/2022: SKP berbasis capaian target + perilaku kerja (BerAKHLAK)."
  },
  {
    id: 71, bagian: "C",
    pertanyaan: "Seorang ASN menerima gratifikasi dari rekanan yang sedang mengikuti tender proyek. Tindakan yang benar sesuai kode etik ASN adalah…",
    opsi: { A: "Menerima saja karena tidak ada yang tahu", B: "Menolak dan melaporkan ke KPK atau unit pengendalian gratifikasi", C: "Menerima setengahnya", D: "Meminta lebih banyak", E: "Mengembalikan tanpa laporan" },
    bobot: { A: 1, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "UU 20/2001 jo. UU Tipikor: gratifikasi wajib ditolak & dilaporkan ke KPK/UPG max 30 hari."
  },
  {
    id: 72, bagian: "C",
    pertanyaan: "ASN dilarang terlibat dalam politik praktis. Berikut yang merupakan bentuk pelanggaran netralitas politik ASN adalah…",
    opsi: { A: "Memberikan suara dalam pemilu", B: "Menjadi pengurus partai politik", C: "Mengikuti upacara bendera", D: "Menghadiri rapat dinas", E: "Membaca berita politik" },
    bobot: { A: 3, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Menjadi pengurus parpol = pelanggaran berat netralitas ASN."
  },
  {
    id: 73, bagian: "C",
    pertanyaan: "Pemerintah Provinsi Kalimantan Tengah mencatat indeks budaya kerja BerAKHLAK meningkat dari 59,5 (2022) menjadi 76,3 (2024). Faktor keberhasilan ini paling mungkin disebabkan oleh…",
    opsi: { A: "Tidak ada perubahan apa pun", B: "Perbaikan mendasar pada implementasi budaya kerja dan internalisasi nilai", C: "Penambahan anggaran secara besar-besaran", D: "Pemutusan hubungan kerja pegawai tidak kompeten", E: "Penggantian seluruh pimpinan" },
    bobot: { A: 1, B: 5, C: 3, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Kenaikan indeks signifikan biasanya hasil internalisasi nilai & perbaikan budaya kerja."
  },
  {
    id: 74, bagian: "C",
    pertanyaan: "Dalam diskusi kelompok tentang pelanggaran core value ASN, CASN di Malang menganalisis kasus di mana ASN ditempatkan tidak sesuai kompetensinya, yang berujung pada layanan publik buruk. Kasus ini melanggar nilai BerAKHLAK, terutama nilai…",
    opsi: { A: "Akuntabel", B: "Berorientasi Pelayanan", C: "Kompeten", D: "Harmonis", E: "Kolaboratif" },
    bobot: { A: 3, B: 4, C: 5, D: 2, E: 2 }, kunci: "C",
    pembahasan: "Penempatan tidak sesuai kompetensi = pelanggaran prinsip Kompeten (right man on the right place)."
  },
  {
    id: 75, bagian: "C",
    pertanyaan: "Pemerintah Kota Metro melakukan survei budaya kerja ASN BerAKHLAK dan menargetkan seluruh ASN sebagai responden. Namun partisipasi hanya 49 persen. Langkah perbaikan yang paling tepat adalah…",
    opsi: { A: "Membiarkan saja", B: "Melakukan pendampingan, sosialisasi ulang, dan intervensi khusus bagi OPD dengan partisipasi rendah", C: "Memecat pegawai yang tidak mengisi survei", D: "Mengulang survei tanpa perbaikan metode", E: "Menghapus survei" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Pendampingan + sosialisasi ulang + intervensi targeted = strategi peningkatan partisipasi."
  },
  {
    id: 76, bagian: "C",
    pertanyaan: "Seorang ASN senior sering memerintah junior untuk melakukan pekerjaan pribadinya. Tindakan ini melanggar kode etik ASN, khususnya prinsip…",
    opsi: { A: "Integritas", B: "Tidak menyalahgunakan wewenang", C: "Profesionalitas", D: "Netralitas", E: "Akuntabilitas" },
    bobot: { A: 3, B: 5, C: 4, D: 2, E: 4 }, kunci: "B",
    pembahasan: "Memerintah junior utk urusan pribadi = penyalahgunaan wewenang (abuse of power)."
  },
  {
    id: 77, bagian: "C",
    pertanyaan: "PP No. 94 Tahun 2021 tentang Disiplin PNS mengatur tingkatan sanksi. Sanksi sedang yang dapat diberikan meliputi…",
    opsi: { A: "Teguran lisan", B: "Penundaan kenaikan pangkat dan gaji", C: "Penurunan jabatan", D: "Pemberhentian tidak hormat", E: "Peringatan tertulis" },
    bobot: { A: 2, B: 5, C: 4, D: 1, E: 3 }, kunci: "B",
    pembahasan: "PP 94/2021: sanksi sedang = pemotongan tukin 25% (6-12 bln) atau penundaan kenaikan pangkat/gaji."
  },
  {
    id: 78, bagian: "C",
    pertanyaan: "ASN yang memiliki nilai 'Berorientasi Pelayanan' akan menunjukkan perilaku berikut, KECUALI…",
    opsi: { A: "Ramah dalam melayani masyarakat", B: "Cepat merespons kebutuhan publik", C: "Memberikan solusi terbaik", D: "Mempersulit proses administrasi", E: "Mendahulukan kepentingan publik" },
    bobot: { A: 4, B: 4, C: 4, D: 5, E: 4 }, kunci: "D",
    pembahasan: "Mempersulit administrasi = LAWAN dari Berorientasi Pelayanan."
  },
  {
    id: 79, bagian: "C",
    pertanyaan: "Surat Edaran MenPANRB No. 20 Tahun 2021 mengatur tentang…",
    opsi: { A: "Pedoman penilaian kinerja", B: "Implementasi Core Values dan Employer Branding ASN", C: "Sistem pengendalian internal", D: "Manajemen pengaduan publik", E: "Netralitas ASN dalam pemilu" },
    bobot: { A: 2, B: 5, C: 2, D: 3, E: 3 }, kunci: "B",
    pembahasan: "SE MenPANRB 20/2021 = peluncuran BerAKHLAK & employer branding 'Bangga Melayani Bangsa'."
  },
  {
    id: 80, bagian: "C",
    pertanyaan: "Core Values BerAKHLAK dan Employer Branding 'Bangga Melayani Bangsa' diluncurkan secara nasional pada tahun…",
    opsi: { A: "2019", B: "2020", C: "2021", D: "2022", E: "2023" },
    bobot: { A: 1, B: 2, C: 5, D: 3, E: 4 }, kunci: "C",
    pembahasan: "BerAKHLAK diluncurkan Presiden Jokowi pada 27 Juli 2021."
  },
  {
    id: 81, bagian: "C",
    pertanyaan: "Seorang ASN memiliki kompetensi yang mumpuni namun sering bersikap individualis dan enggan bekerja sama. Nilai BerAKHLAK yang perlu ditingkatkan dari ASN ini adalah…",
    opsi: { A: "Kompeten", B: "Akuntabel", C: "Kolaboratif", D: "Loyal", E: "Adaptif" },
    bobot: { A: 3, B: 3, C: 5, D: 2, E: 3 }, kunci: "C",
    pembahasan: "Enggan bekerja sama = lemah di nilai Kolaboratif."
  },
  {
    id: 82, bagian: "C",
    pertanyaan: "Dalam Permen PANRB No. 19 Tahun 2025 tentang Penyelenggaraan Sistem Merit, salah satu tujuannya adalah…",
    opsi: { A: "Memperkuat praktik KKN", B: "Mewujudkan ASN yang profesional, netral, bebas KKN", C: "Menghapus sistem promosi", D: "Memperbolehkan nepotisme", E: "Mengurangi jumlah ASN" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Tujuan sistem merit: ASN profesional, netral, bebas KKN — sesuai UU 20/2023."
  },
  {
    id: 83, bagian: "C",
    pertanyaan: "Salah satu indikator keberhasilan implementasi kode etik ASN dalam pelayanan publik adalah…",
    opsi: { A: "Semakin banyak pegawai yang dihukum", B: "Meningkatnya kepercayaan masyarakat terhadap birokrasi", C: "Semakin rumitnya prosedur pelayanan", D: "Semakin banyaknya keluhan masyarakat", E: "Semakin seringnya pergantian pegawai" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Outcome utama kode etik: trust masyarakat meningkat (public trust)."
  },
  {
    id: 84, bagian: "C",
    pertanyaan: "Seorang ASN di lingkungan dinas Anda terlihat membagikan konten provokatif bernuansa SARA di media sosial. Sesuai arahan Wamenko Otto, tindakan yang harus diambil pimpinan adalah…",
    opsi: { A: "Membiarkan karena kebebasan berekspresi", B: "Memberikan pembinaan dan mengingatkan netralitas serta larangan menyebarkan provokasi", C: "Memecat langsung", D: "Menghapus postingan tanpa komunikasi", E: "Memuji postingan tersebut" },
    bobot: { A: 1, B: 5, C: 3, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Pembinaan + edukasi netralitas = pendekatan korektif sesuai kode etik ASN di medsos."
  },
  {
    id: 85, bagian: "C",
    pertanyaan: "Dalam penilaian mandiri maturitas SPIP terintegrasi, seorang ASN yang ditunjuk sebagai asesor harus memiliki kompetensi yang memadai. Hal ini sejalan dengan nilai BerAKHLAK, yaitu…",
    opsi: { A: "Akuntabel", B: "Kompeten", C: "Harmonis", D: "Loyal", E: "Adaptif" },
    bobot: { A: 3, B: 5, C: 2, D: 3, E: 3 }, kunci: "B",
    pembahasan: "Kompetensi asesor = wujud nilai Kompeten ('learn, contribute, succeed')."
  },
  {
    id: 86, bagian: "C",
    pertanyaan: "ASN yang menjaga rahasia negara dan setia kepada Pancasila serta NKRI mencerminkan nilai…",
    opsi: { A: "Berorientasi Pelayanan", B: "Akuntabel", C: "Loyal", D: "Kompeten", E: "Harmonis" },
    bobot: { A: 2, B: 3, C: 5, D: 2, E: 3 }, kunci: "C",
    pembahasan: "Setia pada Pancasila/NKRI + jaga rahasia negara = nilai Loyal."
  },
  {
    id: 87, bagian: "C",
    pertanyaan: "Dalam menghadapi perubahan regulasi dan kebijakan, seorang ASN dituntut untuk cepat beradaptasi. Nilai BerAKHLAK yang paling relevan adalah…",
    opsi: { A: "Harmonis", B: "Loyal", C: "Adaptif", D: "Kolaboratif", E: "Akuntabel" },
    bobot: { A: 2, B: 3, C: 5, D: 3, E: 2 }, kunci: "C",
    pembahasan: "Cepat menyesuaikan diri terhadap perubahan = nilai Adaptif."
  },
  {
    id: 88, bagian: "C",
    pertanyaan: "Program Prioritas BKN Profiling ASN 2025 bertujuan untuk mempercepat tersedianya data potensi dan kompetensi ASN. Manfaat utama program ini adalah…",
    opsi: { A: "Mempermudah mutasi dan promosi berbasis kedekatan", B: "Menyediakan data terstandar untuk pengelolaan ASN berbasis sistem merit", C: "Mengurangi jumlah pegawai", D: "Menghapus sistem penilaian kinerja", E: "Meningkatkan anggaran BKN" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Profiling ASN BKN = fondasi data sistem merit (talent management)."
  },
  {
    id: 89, bagian: "C",
    pertanyaan: "MK menghapus KASN dan memerintahkan pembentukan lembaga pengawas independen ASN. Tujuan dari putusan ini adalah…",
    opsi: { A: "Memperlemah pengawasan ASN", B: "Memastikan pengawasan eksternal yang bebas konflik kepentingan", C: "Menghapus semua lembaga pengawas", D: "Mengembalikan pengawasan ke pimpinan instansi tanpa independensi", E: "Mempersulit pengaduan masyarakat" },
    bobot: { A: 1, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Putusan MK = penguatan pengawasan eksternal independen ASN, bukan pelemahan."
  },
  {
    id: 90, bagian: "C",
    pertanyaan: "Dalam melaksanakan tugasnya, ASN harus menjunjung tinggi prinsip akuntabilitas yang berarti…",
    opsi: { A: "Tidak perlu mempertanggungjawabkan tindakan", B: "Setiap tindakan ASN harus dapat dipertanggungjawabkan sesuai peraturan", C: "Hanya laporan keuangan yang perlu dipertanggungjawabkan", D: "Akuntabilitas hanya untuk pejabat eselon", E: "Akuntabilitas dapat diabaikan jika tidak ada pengawasan" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Akuntabilitas = pertanggungjawaban semua tindakan sesuai aturan, untuk semua level."
  },
  // ====== BAGIAN D: INTEGRASI TKPD-SEKDIN (91-110) ======
  {
    id: 91, bagian: "D",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda menerima laporan melalui SP4N-LAPOR! bahwa pelayanan di salah satu bidang lambat karena prosedur yang berbelit. Sebagai koordinator, langkah yang paling tepat adalah…",
    opsi: { A: "Membiarkan karena sudah menjadi prosedur baku", B: "Mengevaluasi prosedur pelayanan bersama bidang terkait dan menyederhanakan yang tidak perlu", C: "Menyalahkan bidang yang dilaporkan", D: "Menutup laporan tanpa tindak lanjut", E: "Memecat kepala bidang" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Evaluasi & penyederhanaan prosedur = wujud penyederhanaan birokrasi."
  },
  {
    id: 92, bagian: "D",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda menemukan pola bahwa 70 persen pengaduan masyarakat terkait dengan prosedur yang tidak jelas. Anda melaporkan ke Sekretaris Dinas. Tindakan Sekretaris yang paling responsif adalah…",
    opsi: { A: "Mengabaikan laporan", B: "Membentuk tim untuk menganalisis SOP dan merevisi prosedur yang tidak jelas", C: "Menambah jumlah admin", D: "Memperpanjang jam kerja", E: "Menutup kanal pengaduan sementara" },
    bobot: { A: 1, B: 5, C: 3, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Tim analisis SOP + revisi = root cause analysis & perbaikan sistemik."
  },
  {
    id: 93, bagian: "D",
    pertanyaan: "Dalam rapat koordinasi, Kepala Dinas memerintahkan Sekretaris untuk memastikan semua pengaduan masyarakat yang masuk melalui SP4N-LAPOR! ditindaklanjuti maksimal 14 hari. Namun beberapa unit tidak memiliki kapasitas untuk memenuhi target. Sikap Sekretaris yang tepat adalah…",
    opsi: { A: "Memaksa unit memenuhi target tanpa dukungan", B: "Mengidentifikasi kebutuhan sumber daya unit dan mengusulkan peningkatan kapasitas kepada Kepala Dinas", C: "Membiarkan unit gagal", D: "Menurunkan target untuk unit tertentu", E: "Mengalihkan semua pengaduan ke Sekretariat" },
    bobot: { A: 2, B: 5, C: 1, D: 3, E: 2 }, kunci: "B",
    pembahasan: "Identifikasi kebutuhan + capacity building = solusi struktural."
  },
  {
    id: 94, bagian: "D",
    pertanyaan: "Anda adalah Sekretaris Dinas. Sebuah pengaduan masyarakat yang cukup serius masuk melalui SP4N-LAPOR! namun tidak pernah ditindaklanjuti karena admin yang bertanggung jawab sedang cuti. Tindakan yang paling bertanggung jawab adalah…",
    opsi: { A: "Menunggu admin kembali dari cuti", B: "Menunjuk admin pengganti sementara untuk menangani pengaduan", C: "Menutup pengaduan", D: "Mengabaikan karena admin cuti", E: "Menghapus pengaduan" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Plt./admin pengganti = business continuity, layanan tidak boleh berhenti."
  },
  {
    id: 95, bagian: "D",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda mengetahui bahwa Sub Bagian Keuangan sering terlambat dalam memproses verifikasi SPJ, yang menyebabkan keterlambatan respons terhadap pengaduan masyarakat terkait layanan keuangan. Langkah perbaikan yang paling efektif adalah…",
    opsi: { A: "Memberikan sanksi langsung", B: "Melakukan pendampingan, pelatihan, dan monitoring rutin terhadap proses verifikasi", C: "Mengganti seluruh pegawai Sub Bagian Keuangan", D: "Memindahkan fungsi verifikasi ke luar", E: "Membiarkan karena dianggap wajar" },
    bobot: { A: 3, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Pendampingan + pelatihan + monitoring = pendekatan pembinaan berkelanjutan."
  },
  {
    id: 96, bagian: "D",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda menerima laporan dugaan penyalahgunaan wewenang oleh seorang ASN. Berdasarkan arahan pimpinan tentang penegakan kode etik, langkah terbaik Anda adalah…",
    opsi: { A: "Menyimpan laporan secara rahasia untuk dilaporkan ke pimpinan dengan bukti lengkap", B: "Menghapus laporan karena ASN yang dilaporkan adalah atasan", C: "Menyebarluaskan laporan ke media", D: "Menyelesaikan sendiri tanpa koordinasi", E: "Mengabaikan laporan" },
    bobot: { A: 5, B: 1, C: 1, D: 2, E: 1 }, kunci: "A",
    pembahasan: "Kerahasiaan + dokumentasi bukti + laporan ke pimpinan = jalur due process yang benar."
  },
  {
    id: 97, bagian: "D",
    pertanyaan: "Sekretaris Dinas dan admin SP4N-LAPOR! berkolaborasi untuk meningkatkan indeks kepuasan masyarakat terhadap pelayanan. Target peningkatan yang paling realistis dalam 6 bulan ke depan adalah…",
    opsi: { A: "Mencapai 100 persen tanpa peningkatan layanan", B: "Meningkatkan responsivitas pengaduan menjadi di bawah batas maksimal dan menindaklanjuti dengan perbaikan prosedur", C: "Menghapus semua pengaduan", D: "Menutup SP4N-LAPOR!", E: "Memperpanjang batas waktu" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Target SMART: responsivitas < batas maksimal + perbaikan prosedur = realistis & terukur."
  },
  {
    id: 98, bagian: "D",
    pertanyaan: "Dalam pengelolaan anggaran, Sekretaris Dinas menemukan bahwa unit-unit menggunakan anggaran untuk kegiatan yang tidak prioritas sementara layanan publik dasar kekurangan anggaran. Tindakan yang paling sesuai dengan nilai 'Akuntabel' adalah…",
    opsi: { A: "Membiarkan saja", B: "Melakukan evaluasi ulang alokasi anggaran dan mengusulkan realokasi ke kegiatan prioritas", C: "Memotong semua anggaran unit", D: "Menambah anggaran semua unit tanpa evaluasi", E: "Meminta maaf ke masyarakat" },
    bobot: { A: 1, B: 5, C: 3, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Evaluasi + realokasi berbasis prioritas = anggaran berbasis kinerja (PBB)."
  },
  {
    id: 99, bagian: "D",
    pertanyaan: "PermenPAN-RB Nomor 5 Tahun 2025 mengatur batas maksimal tindak lanjut pengaduan. Sebagai Sekretaris Dinas, kebijakan internal yang paling tepat untuk memastikan kepatuhan adalah…",
    opsi: { A: "Membiarkan unit menyesuaikan sendiri", B: "Menetapkan target internal yang lebih ketat dari batas maksimal dan memonitor pencapaiannya", C: "Memperpanjang batas waktu menjadi lebih lama", D: "Menghapus target waktu", E: "Menyerahkan ke unit sepenuhnya" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Internal SLA lebih ketat = buffer untuk kepatuhan regulasi nasional."
  },
  {
    id: 100, bagian: "D",
    pertanyaan: "Anda adalah Sekretaris Dinas. Dalam laporan evaluasi SP4N-LAPOR! triwulan, ditemukan bahwa tingkat responsivitas masih rendah karena koordinasi yang manual dan lambat. Berdasarkan pelajaran dari Kanwil Kemenkum Bali, inovasi yang dapat diadopsi adalah…",
    opsi: { A: "Menambah jumlah rapat koordinasi", B: "Membentuk Satgas SPIP dan memaksimalkan monitoring dashboard untuk pelaporan berkala", C: "Menghapus koordinasi", D: "Memperpanjang batas waktu respons", E: "Menutup SP4N-LAPOR!" },
    bobot: { A: 3, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Satgas SPIP + dashboard monitoring = best practice Kanwil Kemenkum Bali."
  },
  {
    id: 101, bagian: "D",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda dihadapkan pada situasi di mana salah satu kepala bidang enggan berkolaborasi dalam program lintas bidang yang merupakan prioritas pimpinan. Tindakan terbaik adalah…",
    opsi: { A: "Membiarkan karena bukan kewenangan Sekretaris", B: "Memfasilitasi dialog dan menekankan pentingnya kolaborasi untuk mencapai target bersama", C: "Melaporkan ke Kepala Dinas untuk penegakan disiplin", D: "Menjalankan program tanpa bidang tersebut", E: "Membatalkan program" },
    bobot: { A: 2, B: 5, C: 4, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Dialog + persuasi target bersama = fasilitator kolaborasi yang efektif."
  },
  {
    id: 102, bagian: "D",
    pertanyaan: "Sebuah pengaduan masyarakat yang sudah ditindaklanjuti ternyata memiliki bukti baru yang membalikkan fakta awal. Sebagai admin SP4N-LAPOR!, langkah yang paling akuntabel adalah…",
    opsi: { A: "Mengabaikan bukti baru", B: "Membuka kembali proses penanganan dengan mempertimbangkan bukti baru dan berkoordinasi dengan unit terkait", C: "Menghapus pengaduan", D: "Menyalahkan pengadu", E: "Menutup pengaduan tetap" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Bukti baru = open new investigation. Akuntabilitas tidak pernah final."
  },
  {
    id: 103, bagian: "D",
    pertanyaan: "Sekretaris Dinas ingin membangun budaya sadar risiko di seluruh unit. Merujuk pada SE-16/BC/2025 tentang pedoman penyusunan Risk Control Matrix (RCM), langkah pertama yang harus dilakukan adalah…",
    opsi: { A: "Membiarkan unit menyusun sendiri", B: "Memberikan pemahaman kepada Lini I tentang cara menyusun RCM sesuai panduan teknis", C: "Menunjuk konsultan untuk semua unit", D: "Menghapus manajemen risiko", E: "Membeli software RCM" },
    bobot: { A: 2, B: 5, C: 3, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Capacity building Lini I (risk owner) = fondasi budaya sadar risiko."
  },
  {
    id: 104, bagian: "D",
    pertanyaan: "Anda adalah Sekretaris Dinas. Dalam rapat koordinasi, Kepala Dinas menekankan pentingnya sinkronisasi kebijakan TKD dengan perencanaan daerah. Peran Sekretaris yang paling strategis adalah…",
    opsi: { A: "Menyerahkan ke bidang perencanaan", B: "Mengkoordinasikan penyusunan rencana yang selaras antara pusat dan daerah", C: "Mengabaikan karena bukan di level provinsi", D: "Hanya fokus pada pelaporan", E: "Menunggu petunjuk teknis dari pusat tanpa inisiatif" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 3 }, kunci: "B",
    pembahasan: "Sinkronisasi pusat-daerah = peran koordinator strategis Sekdin."
  },
  {
    id: 105, bagian: "D",
    pertanyaan: "Ombudsman menyoroti dugaan pelanggaran netralitas ASN di beberapa daerah. Sebagai Sekretaris Dinas yang memiliki fungsi pembinaan kepegawaian, tindakan paling tepat adalah…",
    opsi: { A: "Mengabaikan karena bukan di wilayah Anda", B: "Memperkuat sosialisasi netralitas ASN, melakukan pengawasan, dan memberikan sanksi tegas jika terbukti melanggar", C: "Melindungi ASN yang melanggar", D: "Membiarkan karena bukan kewenangan", E: "Menghapus aturan netralitas" },
    bobot: { A: 1, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Sosialisasi + pengawasan + sanksi = triad penegakan netralitas ASN."
  },
  {
    id: 106, bagian: "D",
    pertanyaan: "Dalam posisi sebagai Sekretaris Dinas, Anda menerima pengaduan dari masyarakat bahwa ASN di unit pelayanan bersikap diskriminatif terhadap etnis tertentu. Sesuai dengan nilai BerAKHLAK, langkah yang harus diambil adalah…",
    opsi: { A: "Membiarkan karena sudah biasa", B: "Melakukan investigasi, memberikan pembinaan, dan memastikan pelayanan yang tidak diskriminatif", C: "Memindahkan ASN ke unit lain tanpa pembinaan", D: "Menutup kasus", E: "Memecat ASN" },
    bobot: { A: 1, B: 5, C: 3, D: 1, E: 3 }, kunci: "B",
    pembahasan: "Investigasi + pembinaan + jaminan non-diskriminasi = wujud Harmonis + Berorientasi Pelayanan."
  },
  {
    id: 107, bagian: "D",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda melihat ada pengaduan yang masuk dengan identitas pelapor yang tidak jelas. Tindakan paling profesional sesuai standar adalah…",
    opsi: { A: "Menolak pengaduan langsung", B: "Melakukan verifikasi dan jika tidak memungkinkan, memberikan arahan kepada pelapor untuk melengkapi identitas", C: "Meneruskan tanpa verifikasi", D: "Menghapus dari sistem", E: "Memublikasikan identitas" },
    bobot: { A: 3, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Verifikasi + arahan klarifikasi = no wrong door policy + due diligence."
  },
  {
    id: 108, bagian: "D",
    pertanyaan: "Sekretaris Dinas bertanggung jawab atas penyusunan laporan tahunan. Untuk memastikan akurasi data, langkah yang paling tepat adalah…",
    opsi: { A: "Menyalin laporan tahun lalu", B: "Melakukan verifikasi silang data dari seluruh unit sebelum disusun", C: "Mempercayai sepenuhnya data unit tanpa verifikasi", D: "Membuat data sendiri", E: "Menghapus data yang tidak sesuai ekspektasi" },
    bobot: { A: 2, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Cross-check data lintas unit = jaminan akurasi laporan."
  },
  {
    id: 109, bagian: "D",
    pertanyaan: "Anda adalah Sekretaris Dinas. Pimpinan daerah menginstruksikan semua OPD untuk melakukan digitalisasi pelayanan. Sebagai koordinator internal, langkah yang paling tepat adalah…",
    opsi: { A: "Menyerahkan ke bidang IT tanpa koordinasi", B: "Menyusun peta digitalisasi layanan, melibatkan seluruh bidang, dan memastikan kesiapan SDM", C: "Menolak karena sulit", D: "Membeli aplikasi termahal tanpa kajian", E: "Menunggu contoh dari OPD lain" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Roadmap digitalisasi + lintas bidang + kesiapan SDM = transformasi digital terstruktur."
  },
  {
    id: 110, bagian: "D",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda menemukan bahwa proses pengadaan barang sering terlambat karena prosedur yang berbelit. Sikap yang mencerminkan nilai 'Adaptif' adalah…",
    opsi: { A: "Menerima keterlambatan sebagai sesuatu yang wajar", B: "Mengevaluasi dan menyederhanakan prosedur tanpa mengabaikan kepatuhan hukum", C: "Membiarkan proses berjalan seperti biasa", D: "Menyalahkan bagian pengadaan", E: "Memperpanjang tenggat waktu" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 3 }, kunci: "B",
    pembahasan: "Penyederhanaan tanpa korbankan kepatuhan = inovasi Adaptif yang akuntabel."
  },
  // ====== BAGIAN E: HOTS STUDI KASUS (111-150) ======
  {
    id: 111, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas yang baru menjabat. Dalam 3 bulan pertama, Anda mendapati bahwa: (1) Tingkat respons pengaduan SP4N-LAPOR! di bawah 50%; (2) Terdapat indikasi pungli; (3) Kinerja pegawai stagnan dengan banyak yang tidak sesuai kompetensi. Prioritas penanganan yang paling tepat adalah…",
    opsi: { A: "Fokus pada pungli terlebih dahulu karena menyangkut integritas", B: "Fokus pada pengaduan karena menyangkut kepuasan publik", C: "Fokus pada peningkatan kompetensi karena akar masalah", D: "Menangani ketiganya secara simultan dengan pendekatan terintegrasi", E: "Fokus pada kinerja karena menyangkut produktivitas" },
    bobot: { A: 3, B: 3, C: 3, D: 5, E: 2 }, kunci: "D",
    pembahasan: "3 masalah saling terkait — pendekatan terintegrasi simultan = HOTS thinking."
  },
  {
    id: 112, bagian: "E",
    pertanyaan: "Sebuah kasus viral di media sosial tentang pelayanan ASN yang dinilai tidak manusiawi. Dalam 2 jam, berbagai media massa sudah menanyakan klarifikasi. Sebagai Sekretaris Dinas, respons paling kritis yang harus dilakukan adalah…",
    opsi: { A: "Tidak merespons sampai ada arahan pimpinan", B: "Segera mengonfirmasi ke unit terkait, menyiapkan pernyataan resmi, dan mengupdate status di SP4N-LAPOR!", C: "Membiarkan viral mereda dengan sendirinya", D: "Menyalahkan oknum ASN yang bersangkutan tanpa klarifikasi", E: "Menonaktifkan komentar di media sosial" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Crisis communication: konfirmasi internal + pernyataan resmi + update kanal resmi = golden hour response."
  },
  {
    id: 113, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas sekaligus PIC utama SP4N-LAPOR!. Dalam satu minggu, dinas Anda menerima lonjakan pengaduan dari 10 menjadi 150 pengaduan terkait kebijakan baru yang kontroversial. Sementara tim admin hanya berjumlah 2 orang. Manajemen krisis yang paling tepat adalah…",
    opsi: { A: "Mengurangi jam pelayanan", B: "Mengajukan penambahan personel sementara, melakukan triase pengaduan berdasarkan urgensi, dan berkoordinasi dengan unit terkait untuk respons paralel", C: "Memperpanjang batas waktu respons", D: "Menutup sementara kanal pengaduan", E: "Mengabaikan pengaduan yang tidak kritis" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Surge capacity + triase + paralel response = manajemen krisis terbaik."
  },
  {
    id: 114, bagian: "E",
    pertanyaan: "Pemerintah pusat meluncurkan kebijakan reformasi birokrasi yang menuntut setiap OPD menyusun peta proses bisnis dan RCM. Namun, sebagian besar pegawai di lingkungan Anda belum memahami manajemen risiko. Peran Sekretaris yang paling efektif adalah…",
    opsi: { A: "Menunjuk beberapa pegawai untuk belajar sendiri", B: "Menyusun program pelatihan manajemen risiko bertahap, melibatkan narasumber, dan membuat panduan sederhana", C: "Meminta bantuan konsultan untuk seluruh proses", D: "Menunda implementasi sampai tahun depan", E: "Menghapus kebijakan manajemen risiko" },
    bobot: { A: 2, B: 5, C: 4, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Pelatihan bertahap + narasumber + panduan = capacity building berkelanjutan."
  },
  {
    id: 115, bagian: "E",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda menerima pengaduan yang isinya mengancam keselamatan seorang pejabat di dinas Anda. Tindakan yang harus segera dilakukan adalah…",
    opsi: { A: "Menghapus pengaduan", B: "Melaporkan ke pimpinan dan aparat penegak hukum untuk penanganan lebih lanjut", C: "Meneruskan ke unit layanan biasa", D: "Membalas dengan ancaman balik", E: "Mengabaikan karena mungkin hoaks" },
    bobot: { A: 1, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Ancaman keselamatan = ranah pidana, wajib ke APH (Polri/BIN)."
  },
  {
    id: 116, bagian: "E",
    pertanyaan: "Sekretaris Dinas dihadapkan pada pilihan: mendukung kandidat promosi jabatan yang kompeten tetapi kurang populer, atau mendukung kandidat yang populer dan memiliki 'koneksi' namun kompetensinya biasa saja. Prinsip sistem merit menuntut Sekretaris untuk…",
    opsi: { A: "Mendukung kandidat populer agar tidak konflik", B: "Mendukung kandidat yang kompeten karena sesuai aturan dan keadilan", C: "Abstain dari keputusan", D: "Menggabungkan kedua kandidat", E: "Membatalkan promosi" },
    bobot: { A: 2, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Sistem merit = kompetensi & kualifikasi, BUKAN popularitas/koneksi."
  },
  {
    id: 117, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Dalam posisi sebagai koordinator, Anda melihat adanya disharmoni antara dua bidang yang menghambat pelayanan publik. Upaya kolaborasi yang paling konstruktif adalah…",
    opsi: { A: "Memaksa mereka bekerja sama dengan instruksi tegas", B: "Memfasilitasi forum komunikasi rutin, menyusun kesepakatan kerja sama, dan monitoring bersama", C: "Memisahkan tugas mereka agar tidak bersinggungan", D: "Melaporkan ke Kepala Dinas untuk penegakan disiplin", E: "Mengganti kepala kedua bidang" },
    bobot: { A: 3, B: 5, C: 2, D: 3, E: 2 }, kunci: "B",
    pembahasan: "Forum rutin + MoU internal + joint monitoring = team building lintas bidang."
  },
  {
    id: 118, bagian: "E",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda menerima informasi bahwa ada oknum di unit pelayanan menerima suap untuk mempercepat proses perizinan. Tindakan yang paling sesuai dengan integritas adalah…",
    opsi: { A: "Menutup mata karena belum ada bukti kuat", B: "Melakukan investigasi internal, mengumpulkan bukti, dan melaporkan ke inspektorat/APIP", C: "Membongkar sendiri ke media", D: "Memecat oknum tanpa proses", E: "Memindahkan oknum ke unit lain" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Investigasi + bukti + laporan APIP = due process penegakan integritas."
  },
  {
    id: 119, bagian: "E",
    pertanyaan: "Dalam pengelolaan pengaduan, masyarakat sering melaporkan hal yang sama berulang kali karena tidak puas dengan tindak lanjut. Sebagai Sekretaris Dinas yang juga bertanggung jawab atas SP4N-LAPOR!, pendekatan terbaik untuk mengatasi masalah ini adalah…",
    opsi: { A: "Menutup pengaduan setelah respons pertama", B: "Membangun mekanisme umpan balik dan memastikan setiap saran perbaikan diimplementasikan, lalu menginformasikan hasilnya ke pengadu", C: "Mengabaikan pengaduan berulang", D: "Meminta maaf tanpa tindak lanjut", E: "Menghapus kanal pengaduan" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Feedback loop + implementasi + komunikasi = closed-loop pengaduan."
  },
  {
    id: 120, bagian: "E",
    pertanyaan: "Anda diminta menjadi ketua tim perumus RB (Reformasi Birokrasi) dinas. Dalam prosesnya, beberapa pegawai senior menolak perubahan karena merasa nyaman dengan sistem lama. Strategi perubahan yang paling efektif adalah…",
    opsi: { A: "Memaksakan perubahan dengan instruksi", B: "Melibatkan mereka dalam proses perumusan, memberikan pemahaman manfaat perubahan, dan melakukan pendekatan persuasif", C: "Mengabaikan penolakan", D: "Memecat pegawai yang menolak", E: "Membatalkan RB" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Change management Kotter: libatkan stakeholder + komunikasi visi + persuasi."
  },
  {
    id: 121, bagian: "E",
    pertanyaan: "Wakil Menteri LH menyampaikan pentingnya mempercepat mekanisme pelaporan dengan menghilangkan verifikasi berlapis dan langsung memberikan ke unit teknis. Jika Anda adalah Sekretaris Dinas, kebijakan yang paling tepat untuk mengadopsi model ini adalah…",
    opsi: { A: "Mempertahankan verifikasi berlapis", B: "Menyederhanakan alur dengan mengurangi bottleneck dan langsung mengarahkan ke penanggung jawab teknis", C: "Menghapus verifikasi sepenuhnya", D: "Menambah lapisan verifikasi", E: "Menyerahkan ke konsultan" },
    bobot: { A: 2, B: 5, C: 2, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Lean process: hilangkan bottleneck, langsung ke PIC teknis."
  },
  {
    id: 122, bagian: "E",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda menerima 10 pengaduan dalam satu waktu yang sama dengan tingkat urgensi berbeda-beda. Metode prioritas yang paling tepat adalah…",
    opsi: { A: "Memproses berdasarkan urutan masuk", B: "Memproses berdasarkan tingkat urgensi dan dampak dari pengaduan", C: "Memproses berdasarkan kelengkapan data", D: "Memproses yang paling mudah lebih dulu", E: "Memproses yang paling sulit lebih dulu" },
    bobot: { A: 2, B: 5, C: 3, D: 3, E: 2 }, kunci: "B",
    pembahasan: "Eisenhower matrix: urgensi × dampak = prioritas yang paling rasional."
  },
  {
    id: 123, bagian: "E",
    pertanyaan: "Sekretaris Dinas dihadapkan pada situasi di mana anggaran untuk pelatihan pegawai dipotong 50 persen sementara kebutuhan peningkatan kompetensi sangat mendesak. Solusi kreatif yang paling tepat adalah…",
    opsi: { A: "Membatalkan semua pelatihan", B: "Memanfaatkan pelatihan daring gratis, mengoptimalkan in-house training dengan memanfaatkan pegawai yang kompeten sebagai trainer", C: "Meminjam anggaran dari pos lain ilegal", D: "Menunggu tambahan anggaran tahun depan", E: "Mengirim hanya pejabat eselon saja" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "MOOC gratis + in-house trainer = solusi adaptif dengan budget terbatas."
  },
  {
    id: 124, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Salah satu kepala bidang membuat keputusan yang melanggar prosedur tetapi menghasilkan dampak positif cepat. Tindakan yang paling profesional adalah…",
    opsi: { A: "Memuji karena hasilnya positif", B: "Menegur karena melanggar prosedur dan meminta perbaikan prosedur ke depan tanpa mengabaikan kepatuhan", C: "Membiarkan karena tidak ada yang tahu", D: "Memecat kepala bidang", E: "Mengikuti cara yang sama" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Ends don't justify means: tegur pelanggaran + revisi prosedur agar fleksibel."
  },
  {
    id: 125, bagian: "E",
    pertanyaan: "Dalam pengelolaan aset negara, ditemukan bahwa banyak barang inventaris yang rusak dan tidak terawat karena tidak ada jadwal perawatan. Sebagai Sekretaris Dinas, langkah sistematis yang harus dibuat adalah…",
    opsi: { A: "Membeli barang baru semua", B: "Menyusun jadwal perawatan berkala, mengalokasikan anggaran pemeliharaan, dan menugaskan penanggung jawab", C: "Membiarkan barang rusak", D: "Menjual barang rusak", E: "Menghapus dari inventaris tanpa proses" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Preventive maintenance: jadwal + anggaran + PIC = pengelolaan BMD profesional."
  },
  {
    id: 126, bagian: "E",
    pertanyaan: "Anda adalah admin SP4N-LAPOR!. Seorang pengadu mengeluh bahwa laporannya tidak pernah ditindaklanjuti padahal sudah melewati batas waktu. Setelah dicek, laporan tersebut tidak pernah sampai ke unit yang dituju karena kesalahan teknis sistem. Tindakan yang paling bertanggung jawab adalah…",
    opsi: { A: "Menyalahkan sistem", B: "Memproses ulang laporan, meminta maaf ke pengadu, dan memastikan perbaikan sistem agar tidak terulang", C: "Mengabaikan keluhan", D: "Menghapus laporan lama", E: "Menyalahkan pengadu" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Service recovery: proses ulang + maaf + perbaikan sistem = wujud akuntabilitas."
  },
  {
    id: 127, bagian: "E",
    pertanyaan: "Pemerintah daerah mengadakan evaluasi kinerja OPD melalui Sistem Informasi Pemerintah Daerah (SIPD) dengan data real-time. Sebagai Sekretaris Dinas yang memiliki fungsi monitoring, langkah terbaik yang perlu disiapkan adalah…",
    opsi: { A: "Menunggu hasil evaluasi dari pimpinan", B: "Memastikan semua unit mengupdate data secara rutin dan akurat ke dalam SIPD", C: "Memanipulasi data agar terlihat baik", D: "Tidak mengupdate data", E: "Menyerahkan ke pihak ketiga" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Data discipline: update rutin & akurat = fondasi e-government."
  },
  {
    id: 128, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Ketika melakukan evaluasi organisasi dan tata laksana, ditemukan bahwa struktur organisasi dinas sudah tidak relevan dengan beban kerja saat ini. Rekomendasi yang paling tepat adalah…",
    opsi: { A: "Tidak melakukan perubahan", B: "Mengusulkan penataan ulang struktur organisasi berdasarkan analisis beban kerja dan kebutuhan", C: "Menambah jumlah pegawai tanpa restrukturisasi", D: "Mengurangi pegawai drastis", E: "Mengikuti struktur OPD lain tanpa analisis" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "ABK (Analisis Beban Kerja) = basis penataan struktur organisasi."
  },
  {
    id: 129, bagian: "E",
    pertanyaan: "Dalam penanganan pengaduan masyarakat melalui SP4N-LAPOR!, ditemukan bahwa koordinasi dengan instansi lain sering terhambat karena perbedaan sistem. Sebagai Sekretaris Dinas, inisiatif yang paling strategis adalah…",
    opsi: { A: "Mengeluh ke instansi lain", B: "Menginisiasi nota kesepahaman (MoU) lintas instansi untuk standarisasi dan integrasi data", C: "Menutup kanal pengaduan lintas instansi", D: "Memproses semua pengaduan sendiri tanpa koordinasi", E: "Menunggu inisiatif dari instansi lain" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "MoU lintas instansi = wujud Kolaboratif untuk standarisasi data."
  },
  {
    id: 130, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Sebagai pelaksana fungsi kehumasan, Anda harus merespons isu negatif yang beredar tentang dinas Anda di media sosial. Strategi komunikasi krisis yang paling profesional adalah…",
    opsi: { A: "Mengabaikan isu negatif", B: "Merespons secara proaktif dengan klarifikasi berdasarkan data dan fakta, membuka ruang dialog", C: "Memerintahkan staf untuk membuat akun palsu membela dinas", D: "Menghapus komentar negatif di media sosial", E: "Menyalahkan pihak lain" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Crisis comm: proaktif + fakta + dialog terbuka = damage control yang sehat."
  },
  {
    id: 131, bagian: "E",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda menemukan bahwa ada pegawai yang memiliki potensi besar namun sering frustrasi karena tidak ada jenjang karier yang jelas. Tindakan yang paling sesuai dengan nilai 'Akuntabel' dalam pengembangan SDM adalah…",
    opsi: { A: "Membiarkan saja", B: "Mengusulkan program pengembangan karier, mentoring, dan rotasi yang terstruktur", C: "Memindahkannya tanpa rencana", D: "Memberikan promosi tanpa evaluasi", E: "Mengabaikan karena bukan prioritas" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Career path + mentoring + rotasi terstruktur = talent retention."
  },
  {
    id: 132, bagian: "E",
    pertanyaan: "Dalam penyusunan rencana kegiatan dan program kerja Dinas, beberapa bidang mengajukan usulan kegiatan yang tidak jelas dampaknya terhadap pelayanan publik. Sebagai Sekretaris yang mengoordinasikan, tindakan yang paling tepat adalah…",
    opsi: { A: "Menyetujui semua usulan", B: "Menolak semua usulan", C: "Melakukan review usulan dengan kriteria prioritas dan keterkaitan dengan rencana strategis", D: "Menyerahkan ke pimpinan tanpa review", E: "Memotong anggaran semua usulan" },
    bobot: { A: 1, B: 2, C: 5, D: 2, E: 2 }, kunci: "C",
    pembahasan: "Review berbasis prioritas + alignment dengan Renstra = perencanaan logis."
  },
  {
    id: 133, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Dalam rapat dengan Inspektorat, ditemukan bahwa kesalahan administratif dalam pengelolaan keuangan dinas Anda tergolong tinggi. Tindakan perbaikan paling mendasar adalah…",
    opsi: { A: "Mengganti bendahara", B: "Memperkuat sistem pengendalian internal, pelatihan, dan pengawasan melekat", C: "Menambah anggaran", D: "Menyerahkan pengelolaan keuangan ke pihak luar", E: "Menghapus pos anggaran tertentu" },
    bobot: { A: 2, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "SPIP + pelatihan + waskat = perbaikan sistemik (bukan sekadar ganti orang)."
  },
  {
    id: 134, bagian: "E",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda menerima pengaduan yang menunjukkan bahwa ada pegawai yang sering terlambat dan mengabaikan tanggung jawab. Sebagai bagian dari Sekretariat yang menangani administrasi kepegawaian, tindakan yang tepat adalah…",
    opsi: { A: "Merahasiakan pengaduan", B: "Mengonfirmasi kebenaran pengaduan ke unit terkait, memberikan pembinaan, dan dokumentasikan untuk pembinaan kepegawaian", C: "Memecat pegawai", D: "Menghapus pengaduan", E: "Memublikasikan identitas pegawai" },
    bobot: { A: 2, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Konfirmasi + pembinaan + dokumentasi = proses pembinaan kepegawaian yang adil."
  },
  {
    id: 135, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Pimpinan memerintahkan untuk melakukan efisiensi anggaran 20 persen tanpa mengurangi output pelayanan. Strategi yang paling tepat adalah…",
    opsi: { A: "Memotong semua kegiatan", B: "Mengidentifikasi kegiatan yang tidak prioritas, melakukan penghematan tanpa mengorbankan layanan inti", C: "Memotong gaji pegawai", D: "Memotong belanja modal", E: "Mengurangi jam pelayanan" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Cut the fat, not the muscle: identifikasi non-prioritas, lindungi layanan inti."
  },
  {
    id: 136, bagian: "E",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda melakukan monitoring realisasi anggaran dan menemukan bahwa hingga semester II realisasi baru 30 persen. Analisis awal menunjukkan perencanaan yang kurang matang. Tindakan korektif yang paling tepat adalah…",
    opsi: { A: "Mempercepat realisasi di akhir tahun dengan belanja tanpa perencanaan", B: "Mengevaluasi penyebab keterlambatan, memperbaiki perencanaan tahun depan, dan mengoptimalkan sisa waktu sesuai aturan", C: "Membiarkan saja", D: "Mengembalikan sisa anggaran tanpa usulan", E: "Menambah kegiatan tanpa perencanaan" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Root cause + perbaikan perencanaan + optimasi sisa waktu = manajemen anggaran prudent."
  },
  {
    id: 137, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas yang menangani urusan hubungan masyarakat. Sebuah media massa menyebutkan bahwa dinas Anda tidak transparan dalam pengelolaan keuangan. Padahal semua laporan sudah tersedia di website. Strategi yang paling efektif adalah…",
    opsi: { A: "Menggugat media ke pengadilan", B: "Merespons dengan data bahwa semua laporan tersedia dan dapat diakses, serta membuka dialog dengan media", C: "Mengabaikan pemberitaan", D: "Menutup akses laporan keuangan", E: "Mengganti pejabat humas" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Klarifikasi berbasis data + dialog = damage control elegan untuk media."
  },
  {
    id: 138, bagian: "E",
    pertanyaan: "Dalam menyusun laporan bulanan, triwulan, semesteran, dan tahunan, Sub Bagian Keuangan diminta untuk menyajikan data dengan cepat. Namun staf sering mengeluh kewalahan karena banyaknya laporan. Solusi sistemik yang paling baik adalah…",
    opsi: { A: "Mengurangi frekuensi pelaporan", B: "Membangun sistem informasi keuangan terintegrasi yang dapat menghasilkan laporan secara otomatis", C: "Menambah staf penginput data", D: "Memperpanjang deadline", E: "Menghapus beberapa jenis laporan" },
    bobot: { A: 2, B: 5, C: 3, D: 2, E: 2 }, kunci: "B",
    pembahasan: "SIM keuangan terintegrasi + automated reporting = solusi sistemik, bukan tambal sulam."
  },
  {
    id: 139, bagian: "E",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda menemukan bahwa beberapa pegawai memiliki keterampilan digital yang rendah sementara tuntutan digitalisasi semakin tinggi. Program pengembangan yang paling tepat adalah…",
    opsi: { A: "Membiarkan mereka pensiun", B: "Menyusun program pelatihan digital bertahap dengan pendampingan", C: "Memecat pegawai yang tidak mampu", D: "Merekrut pegawai baru untuk menggantikan", E: "Membatalkan digitalisasi" },
    bobot: { A: 2, B: 5, C: 1, D: 3, E: 1 }, kunci: "B",
    pembahasan: "Digital upskilling bertahap + pendampingan = inclusive transformation."
  },
  {
    id: 140, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Dalam fungsi sebagai koordinator, Anda melihat ketimpangan beban kerja antara satu bidang dengan bidang lainnya. Langkah yang paling adil dan efektif adalah…",
    opsi: { A: "Membiarkan karena sudah menjadi risiko tugas", B: "Melakukan analisis beban kerja dan mengusulkan penyesuaian tugas serta keseimbangan beban antar bidang", C: "Memindahkan semua pekerjaan ke bidang dengan beban ringan", D: "Memberikan bonus pada bidang yang kelebihan beban", E: "Memotong pekerjaan bidang dengan beban ringan" },
    bobot: { A: 2, B: 5, C: 2, D: 3, E: 2 }, kunci: "B",
    pembahasan: "ABK + redistribusi tugas = workload balancing yang adil."
  },
  {
    id: 141, bagian: "E",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda mendapati bahwa pimpinan unit tidak responsif terhadap pengaduan yang diteruskan. Upaya yang paling konstruktif untuk mengatasi ini adalah…",
    opsi: { A: "Melaporkan ke atasan pimpinan pimpinan unit tersebut", B: "Membangun komunikasi rutin dengan pimpinan unit, menyepakati mekanisme koordinasi dan pelaporan", C: "Menghentikan penerusan pengaduan ke unit tersebut", D: "Menambah frekuensi teguran", E: "Meneruskan ke media" },
    bobot: { A: 4, B: 5, C: 2, D: 3, E: 2 }, kunci: "B",
    pembahasan: "Komunikasi rutin + SOP koordinasi = solusi konstruktif vs eskalasi."
  },
  {
    id: 142, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Dalam rapat koordinasi dengan BPKP selaku instansi pengampu SPIP, disepakati bahwa diperlukan Satgas SPIP di level dinas. Langkah pembentukan yang paling tepat adalah…",
    opsi: { A: "Menunjuk staf secara acak", B: "Membentuk Satgas dengan komposisi yang sesuai fungsi, memberikan pelatihan, dan menetapkan mekanisme pelaporan yang jelas", C: "Menyerahkan ke BPKP", D: "Menunda pembentukan", E: "Membentuk hanya di atas kertas" },
    bobot: { A: 2, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Satgas SPIP = komposisi sesuai fungsi + pelatihan + mekanisme lapor = struktural & fungsional."
  },
  {
    id: 143, bagian: "E",
    pertanyaan: "Sebagai Sekretaris Dinas, Anda harus memastikan penerapan prinsip no wrong door policy dalam pelayanan. Hal ini berarti…",
    opsi: { A: "Semua pintu harus terbuka 24 jam", B: "Masyarakat dapat menyampaikan keluhan melalui berbagai kanal dan tetap akan diproses dengan baik", C: "Hanya ada satu pintu pelayanan", D: "Pintu harus dilengkapi kamera CCTV", E: "Tidak boleh ada pintu di kantor" },
    bobot: { A: 2, B: 5, C: 2, D: 2, E: 1 }, kunci: "B",
    pembahasan: "No wrong door: lewat kanal mana pun, pengaduan tetap diproses."
  },
  {
    id: 144, bagian: "E",
    pertanyaan: "Data SP4N-LAPOR! menunjukkan peningkatan pengaduan dari tahun ke tahun. Sebagai Sekretaris Dinas, fenomena ini dapat diinterpretasikan sebagai…",
    opsi: { A: "Penurunan kualitas pelayanan secara drastis", B: "Meningkatnya kepercayaan masyarakat terhadap sistem pengaduan dan kesadaran masyarakat untuk menyampaikan aspirasi", C: "Kegagalan sistem pengaduan", D: "Masyarakat yang terlalu banyak mengeluh", E: "Lemahnya pengawasan internal" },
    bobot: { A: 2, B: 5, C: 1, D: 1, E: 2 }, kunci: "B",
    pembahasan: "Reframing: lonjakan pengaduan = sinyal trust meningkat & kesadaran civic engagement."
  },
  {
    id: 145, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Pimpinan meminta Anda untuk memastikan bahwa seluruh pegawai memiliki Pakta Integritas. Namun beberapa pegawai keberatan dengan alasan formalitas. Pendekatan yang paling tepat adalah…",
    opsi: { A: "Memaksa semua menandatangani", B: "Melakukan sosialisasi makna Pakta Integritas, contoh pelanggaran dan sanksinya, serta menekankan pentingnya komitmen bersama", C: "Membebaskan pegawai yang keberatan", D: "Menghapus kewajiban Pakta Integritas", E: "Menandatangani untuk semua pegawai" },
    bobot: { A: 3, B: 5, C: 2, D: 1, E: 1 }, kunci: "B",
    pembahasan: "Sosialisasi makna + contoh + komitmen bersama = internalisasi, bukan paksaan."
  },
  {
    id: 146, bagian: "E",
    pertanyaan: "Dalam posisi sebagai Sekretaris Dinas, Anda menerima laporan bahwa program unggulan dinas tidak berjalan sesuai target. Evaluasi menunjukkan kurangnya koordinasi antar bidang. Akar masalah ini paling tepat diatasi dengan…",
    opsi: { A: "Mengganti penanggung jawab program", B: "Memperkuat mekanisme koordinasi berkala yang dipimpin Sekretaris sebagai koordinator", C: "Membatalkan program", D: "Menambah anggaran", E: "Memperpanjang waktu program" },
    bobot: { A: 2, B: 5, C: 1, D: 2, E: 2 }, kunci: "B",
    pembahasan: "Koordinasi berkala dipimpin Sekdin = peran inti koordinator lintas bidang."
  },
  {
    id: 147, bagian: "E",
    pertanyaan: "Sebagai admin SP4N-LAPOR!, Anda melihat ada oknum yang mengirimkan pengaduan bohong (hoaks) berulang kali dengan identitas berbeda-beda. Tindakan paling sesuai standar adalah…",
    opsi: { A: "Memblokir semua pengaduan dari identitas tersebut", B: "Melaporkan ke pimpinan untuk verifikasi silang dan jika terbukti hoaks, tetap memberikan edukasi kepada pelapor", C: "Membalas dengan nada sinis", D: "Meneruskan semua pengaduan tanpa filter", E: "Menutup sistem sementara" },
    bobot: { A: 3, B: 5, C: 1, D: 2, E: 1 }, kunci: "B",
    pembahasan: "Verifikasi silang + edukasi pelapor = pendekatan persuasif tanpa diskriminasi."
  },
  {
    id: 148, bagian: "E",
    pertanyaan: "Anda adalah Sekretaris Dinas. Sebagai pelaksana fungsi protokol, Anda harus mengatur kunjungan Menteri ke dinas Anda. Prinsip yang harus dipegang dalam penyelenggaraan protokol adalah…",
    opsi: { A: "Mewah berlebihan untuk menunjukkan kesan baik", B: "Efisien, efektif, dan sesuai dengan ketentuan yang berlaku", C: "Sesuai keinginan tamu tanpa batasan", D: "Minimalis hingga mengabaikan standar keselamatan", E: "Dipotong anggarannya seminimal mungkin" },
    bobot: { A: 1, B: 5, C: 2, D: 2, E: 2 }, kunci: "B",
    pembahasan: "UU 9/2010 Keprotokolan: efisien, efektif, sesuai aturan."
  },
  {
    id: 149, bagian: "E",
    pertanyaan: "KLH/BPLH berhasil menekan proses AMDAL dari 168 hari menjadi 51 hari. Jika Anda menjadi Sekretaris Dinas yang ingin menerapkan efisiensi serupa pada proses perizinan di dinas Anda, langkah awal yang paling kritis adalah…",
    opsi: { A: "Memotong semua prosedur tanpa analisis", B: "Memetakan seluruh proses bisnis, mengidentifikasi bottleneck, dan menyusun peta perbaikan dengan target bertahap", C: "Menambah jumlah petugas perizinan", D: "Mengalihkan ke pihak ketiga", E: "Mencontoh mentah-mentah model KLH tanpa penyesuaian" },
    bobot: { A: 2, B: 5, C: 3, D: 2, E: 3 }, kunci: "B",
    pembahasan: "BPR (Business Process Reengineering): mapping → identifikasi bottleneck → roadmap."
  },
  {
    id: 150, bagian: "E",
    pertanyaan: "Di akhir masa jabatan Anda sebagai Sekretaris Dinas, Anda diminta menyusun laporan pertanggungjawaban. Nilai ASN BerAKHLAK yang paling utama harus tercermin dalam laporan tersebut adalah…",
    opsi: { A: "Harmonis dan Adaptif", B: "Akuntabel dan Berorientasi Pelayanan (laporan yang jujur, transparan, dan berfokus pada kepentingan publik)", C: "Loyal dan Kompeten", D: "Kolaboratif saja", E: "Adaptif saja" },
    bobot: { A: 3, B: 5, C: 4, D: 2, E: 2 }, kunci: "B",
    pembahasan: "LPJ akhir jabatan = laporan jujur (Akuntabel) + fokus publik (Berorientasi Pelayanan)."
  }
];

// Helper function: shuffle array (Fisher-Yates)
window.shuffleArray = function(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

// Pick N random unique soal, distribute across bagian
window.pickRandomSoal = function(n = 45) {
  // Distribusi proporsional: A=35, B=25, C=30, D=20, E=40 → total 150
  // 45 soal target: A≈10, B≈8, C≈9, D=6, E=12
  const byBagian = { A: [], B: [], C: [], D: [], E: [] };
  window.BANK_SOAL.forEach(s => byBagian[s.bagian].push(s));
  const targetPerBagian = { A: 10, B: 8, C: 9, D: 6, E: 12 };
  let result = [];
  for (const k of ["A", "B", "C", "D", "E"]) {
    const shuffled = window.shuffleArray(byBagian[k]);
    result = result.concat(shuffled.slice(0, targetPerBagian[k]));
  }
  return window.shuffleArray(result);
};
