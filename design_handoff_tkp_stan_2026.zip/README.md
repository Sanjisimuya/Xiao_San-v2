# Handoff: TKP STAN 2026 Learning Hub

## Overview

A futuristic-themed web application for students preparing for the **Tes Karakteristik Pribadi (TKP)** section of the **PKN STAN 2026** (Politeknik Keuangan Negara STAN) entrance exam. The product has three primary surfaces:

1. **Landing page** — hero, value props, and module previews
2. **Materi (Learning Material)** — 5 in-depth modules covering the full TKP HOTS curriculum (TKPD, Sekretaris Dinas, BerAKHLAK, Integration, Complex Case Studies), each minimum one full page long, grounded in the latest 2025–2026 regulations
3. **Latihan (Quiz Simulator)** — a 45-question / 45-minute timed simulation that pulls randomly from a bank of 150 HOTS questions, auto-advances on answer selection, and shows a full review screen at the end with correct/incorrect explanations

The scoring is **TKP-style weighted**: each option carries a weight of 1–5 (5 = most appropriate ASN behavior). Maximum score per session = 225. Distribution is fixed per session: 10 Module A · 8 Module B · 9 Module C · 6 Module D · 12 Module E. Sessions are non-repeating — a fresh random draw every time the user starts.

---

## About the Design Files

The files bundled here (`index.html`, `materi.html`, `latihan.html`, `assets/style.css`, `data/soal.js`) are **design references created in HTML** — interactive prototypes showing the intended look, motion, copy, and behavior. They are **not production code to ship directly**.

**The implementation task is to recreate these HTML designs inside the target codebase's existing environment** — React, Vue, SvelteKit, Next.js, Astro, SwiftUI, Flutter, native Android, or whatever framework the project is using — applying the codebase's established patterns, component library, routing, and state management.

If there is no existing environment yet (greenfield), pick the most appropriate framework for the project (a SPA framework like Next.js or SvelteKit fits this multi-page interactive content very well) and implement the designs there.

The 150-question bank in `data/soal.js` IS production-quality data — port it as-is into a JSON file, database table, or CMS entry depending on the target architecture.

---

## Fidelity

**High-fidelity (hifi)** — Pixel-precise mockups with final colors, typography, motion timing, and complete interaction logic. The developer should recreate the UI with the same visual fidelity using the codebase's existing libraries and patterns.

---

## Tech Stack of the Prototype

- Plain HTML5 + CSS3 + vanilla ES2020 JavaScript (no build step)
- Google Fonts: `Space Grotesk` (display) + `JetBrains Mono` (mono/code)
- No external runtime dependencies — everything inlined or self-contained
- `localStorage` for: last-viewed material tab persistence
- No backend — the question bank is a static JS array shipped with the page

For the real product, the developer can keep this architecture (it's small and works offline) or move to:
- A framework like Next.js / SvelteKit for routing & data fetching
- A headless CMS (Sanity, Strapi) or simple JSON file for the question bank
- Optional: a backend to track attempt history, user accounts, leaderboards (not required for v1)

---

## Screens / Views

### 1. Landing Page (`index.html`)

**Purpose:** Welcome the user, communicate value, and route them to either Materi or Latihan.

**Layout:**
- Sticky top navigation bar (60px tall, blurred dark glass)
- Hero section (`min-height: calc(100vh - 80px)`, two-column grid 1.2fr/1fr, collapses to single column below 900px)
  - Left column: eyebrow, h1, descriptive paragraph, two CTAs, 3-stat row
  - Right column: holographic info panel with animated scanline
- Module grid section (`auto-fit, minmax(280px, 1fr)`, 6 cards: 5 modules + 1 "Mulai Simulasi" CTA card)
- Final CTA banner (3-column flex: large mono symbol + heading + button)
- Footer (centered mono text)

**Components:**

- **Top Nav** (sticky, z-index 50)
  - Brand: 36×36px gradient square (cyan→purple) + "TKP STAN" + "LEARNING HUB · 2026" subtitle
  - Right links: Beranda / Materi / Latihan, 14px font, active state has `inset 0 -2px 0 var(--cyan)` underline

- **Hero Headline (h1)**
  - `font-size: clamp(2.4rem, 5vw, 4rem); font-weight: 700; line-height: 1.05`
  - "TKP **STAN 2026**" middle phrase uses gradient text (cyan → purple → magenta)

- **Primary CTA** "Mulai Belajar"
  - `padding: 14px 28px; border-radius: 10px`
  - `background: linear-gradient(135deg, #00f0ff, #b347ff); color: #050814`
  - `box-shadow: 0 8px 24px rgba(0, 240, 255, 0.3)`
  - On hover: `transform: translateY(-3px); box-shadow: 0 12px 36px rgba(0, 240, 255, 0.5)`

- **Stat Card** (3 of them: "150 BANK SOAL", "45min DURASI", "5 MODUL")
  - Big number uses gradient text; label is 12px mono uppercase, color `var(--text-2)`

- **Holographic Panel** (right side of hero)
  - `aspect-ratio: 1 / 1.05; max-width: 480px; border-radius: 24px`
  - Layered radial gradients + 24px grid overlay
  - Animated scanline: 2px tall horizontal cyan strip, animation `scanline 4s linear infinite` (slides from top:-100% to top:100vh)
  - Status list with mono font, dashed dividers, value column in cyan ("READY", "ONLINE", "UPDATED")

- **Module Card** (6 cards in module-grid)
  - `padding: 28px 24px; border-radius: 16px`
  - 4px left accent bar (gradient cyan→purple) hidden by default, fades in on hover
  - On hover: `transform: translateY(-4px); box-shadow: var(--glow-cyan)`
  - Last card ("Mulai Simulasi") has gradient background + stronger border + green "▶ MULAI" tag

### 2. Materi Page (`materi.html`)

**Purpose:** Deliver the 5-module curriculum with tab-style navigation.

**Layout:**
- Same top nav
- Two-column layout (`grid-template-columns: 280px 1fr; gap: 40px`)
  - Left: sticky sidebar with 5 module links + "Latihan Soal" CTA, max-height with overflow scroll
  - Right: content area (one of 5 article panes visible at a time via `.active` class)
- Below 980px breakpoint: collapses to single column (sidebar stacks above content)

**Components:**

- **Sidebar Link**
  - `padding: 12px 14px; border-radius: 10px`
  - Inactive: transparent border, text `var(--text-1)`
  - Active: `background: rgba(0, 240, 255, 0.1); color: var(--cyan); border-color: var(--border)`
  - Badge (question count) on the right: pill, mono 10px, in cyan; inverted on active

- **Pane Header** (per module)
  - Gradient background `linear-gradient(135deg, rgba(0,240,255,0.06), rgba(179,71,255,0.06))`
  - `padding: 32px; border-radius: 20px`
  - Decorative radial gradient blob in top-right corner
  - Contains: eyebrow tag, h1 title, and a row of tags showing relevant regulations + question count

- **Content Typography**
  - h2: `font-size: 1.5rem; margin: 36px 0 16px` with 4px gradient accent bar on the left
  - h3: `color: var(--cyan); margin: 24px 0 10px; font-size: 1.1rem`
  - Body p: `color: var(--text-1); margin-bottom: 14px`
  - `<strong>` snaps to `var(--text-0)`, `<em>` snaps to `var(--cyan)`
  - `<code>` inline: mono 0.88em, padding 2px 7px, cyan tinted background

- **Info / Warn / Pro-Tip Boxes**
  - Common: `border-radius: 12px; padding: 16px 20px; border-left: 3px solid <color>`
  - Info: cyan accent + `rgba(0, 240, 255, 0.05)` background
  - Warn: yellow accent + `rgba(255, 216, 77, 0.06)`
  - Pro-tip: purple accent + `rgba(179, 71, 255, 0.06)`
  - Title strip (uppercase mono 11px) auto-colored to match accent

- **Data Tables**
  - `background: var(--surface); border-radius: 10px; overflow: hidden`
  - Header row: cyan-tinted background, mono uppercase, color var(--cyan)
  - Body row hover: subtle cyan tint
  - Cell padding: 12px 16px

- **Mini-card grid (2-column)**
  - `grid-template-columns: 1fr 1fr; gap: 16px`
  - Each card: surface bg + border + 12px radius; label (mono 10px) + value (16px regular)

- **Quote / Blockquote** for direct citations
  - Left border 3px magenta, `padding: 12px 20px`, italic, light magenta background

- **Pane Footer** — bottom of each module
  - Dashed border, two-column flex: current module label on left, "next module" link on right (cyan, clickable, triggers `switchTo()`)

**Tab switching JS:**
```js
function switchTo(targetId) {
  // hide all .section-pane, show #targetId
  // toggle .active on sidebar links
  // updates URL hash + localStorage('tkp_materi_last')
  // smooth scrolls .content to top
}
```
On load: reads `location.hash` first, then `localStorage`, defaults to `'bagian-a'`.

### 3. Latihan Page (`latihan.html`)

**Purpose:** Run a 45-question / 45-minute quiz session with auto-advance and final review.

This page has **three sub-screens** controlled by `display: none/block`:

#### 3a. Start Screen (`#screen-start`)
- Centered column, `max-width: 760px; padding: 64px 24px`
- Eyebrow → h1 ("Simulasi 45 Soal · 45 Menit") → lead paragraph
- 3-stat row: "45 SOAL ACAK", "45:00 DURASI", "225 SKOR MAKSIMAL"
- Rules card (`#rules-card`): list of 6 instruction bullets with circle bullet markers in cyan
- Big primary CTA button — clicking it kicks off the quiz

#### 3b. Quiz Screen (`#screen-quiz`)
- **Sticky quiz bar** (top: 70px, z-index 30, blurred dark bg)
  - Left: counter "Soal **N**/45" (mono)
  - Center: progress bar (6px tall, gradient fill, `box-shadow: 0 0 12px rgba(0, 240, 255, 0.6)`)
  - Right: timer pill + "Akhiri" ghost button
  - Timer states (driven by `timeLeft` value):
    - Default: cyan
    - `<= 300s` (5 min): adds `.warning` class — yellow, `pulse-glow 1.5s infinite`
    - `<= 60s` (1 min): adds `.danger` class — red, `pulse-glow 0.8s infinite`

- **Question Card** (`#q-card`)
  - `background: var(--surface); border-radius: 20px; padding: 36px`
  - Animation on render: `slideIn 0.35s cubic-bezier(0.16, 1, 0.3, 1)` (opacity 0→1 + translateY 20px→0)
  - Meta row: "QUESTION **N**/45" (left) + "MODUL · A" purple-tinted pill (right)
  - Question text: 1.1rem, line-height 1.7
  - Options (`<button>` not radio): vertical stack, 12px gap
    - Each: 16px 20px padding, 1px border, 12px radius, transparent bg
    - Left: 32×32px square letter badge (A/B/C/D/E), mono 14px bold, cyan-tinted bg
    - Hover: cyan border, `translateX(4px)`, `rgba(0, 240, 255, 0.05)` bg
    - Selected: cyan border + glow + letter badge inverts to solid cyan
  - Skip button at bottom-right of card (ghost style, 13px)

**Auto-advance behavior:**
- User clicks an option → that option gets `.selected`, all options get `disabled` → 380ms delay → next question renders.
- Skip → mark answer as `{picked: null, bobot: 0}` → next.
- On last question's answer/skip → finish quiz.

#### 3c. Result Screen (`#screen-result`)

- **Result Hero**
  - `padding: 48px; border-radius: 24px`
  - Background: dual radial gradient layer + 40px grid overlay
  - Score display: huge mono number (5rem) in gradient text, e.g. "187" with grey "/225" suffix
  - Performance message paragraph (one of 4 messages depending on percentage):
    - ≥85% → "Luar biasa! ..."
    - ≥70% → "Bagus! ..."
    - ≥55% → "Cukup baik. ..."
    - <55% → "Masih perlu banyak latihan. ..."
  - **Result bars** (4 cards, auto-fit grid):
    - Green: "JAWABAN OPTIMAL (+5)" → count of answers where bobot === 5
    - Yellow: "CUKUP (3–4)" → count where bobot 3 or 4
    - Red: "KURANG (1–2)" → count where bobot 1 or 2
    - Cyan: "DILEWATI" → count of skipped/null answers
  - CTA row: "Coba Lagi (Soal Baru)" primary + "Kembali ke Materi" + "Beranda" ghost links

- **Review Section** (full list of all 45 questions)
  - Section header h2 with same gradient accent bar
  - **Filter buttons** (5 pills): All / Kurang / Cukup / Optimal / Dilewati — active state inverts to solid cyan
  - **Review Item** (one per question):
    - 4px left-border color-coded by status (green/yellow/red/grey)
    - Head row: "Soal #N · Modul X" on left + status pill on right
      - Status pill text varies: `OPTIMAL · +5`, `CUKUP · +3`, `KURANG · +1`, `DILEWATI`
    - Question text in full
    - All 5 options listed; per option:
      - User's pick gets `.user-pick` class (cyan border + tint)
      - Correct answer gets `.kunci` class (green border + tint)
      - If user pick === correct answer, both classes apply (green dominates)
      - Right side: `+N` weight badge in mono pill
    - Picked info line: "Pilihan Anda: **X** (+N) · Kunci optimal: **Y** (+5)"
    - Pembahasan box: purple left-border, mono "// PEMBAHASAN" header, body text from `soal.pembahasan`

- **Quit Modal** (`#modal-quit`)
  - Hidden by default (`display: none`), shown by adding `.open` class (`display: grid`)
  - Fixed full-screen mask with blur backdrop
  - Modal: 420px max-width, centered, 32px padding, 20px radius
  - "Akhiri Simulasi?" title + warning paragraph + Batal/Ya buttons

---

## Interactions & Behavior

### Quiz Engine — Detailed Logic

**Random Question Picker** (`window.pickRandomSoal(n)` in `data/soal.js`):
```js
// Distribution per session: A=10, B=8, C=9, D=6, E=12 (totals 45)
// Bank distribution: A=35, B=25, C=30, D=20, E=40 (totals 150)
// Algorithm: shuffle each section's pool (Fisher-Yates), slice the target count, concatenate, then shuffle the final 45 for delivery order.
```
This guarantees:
- **No duplicates within a session** (each soal picked at most once)
- **Different sessions = different soal sets** (or at minimum different orderings — re-shuffle on every call)
- **Proportional curriculum coverage** every time

**State Variables** (in `latihan.html`):
```js
let soalList = [];        // The 45 selected questions for this session
let userAnswers = [];     // [{qid, picked: 'A'|'B'|.., bobot: 0..5}] — picked=null means skipped
let currentIdx = 0;       // 0..44, which question is currently displayed
let timeLeft = 45 * 60;   // seconds remaining
let timerInterval = null; // setInterval handle
let quizStartTime = 0;    // Date.now() at session start
```

**Timer**:
- `setInterval` ticking every 1000ms, decrements `timeLeft`
- On each tick: update display + recompute `.warning`/`.danger` class
- When `timeLeft <= 0`: clear interval, call `finishQuiz()`

**Answer Selection Flow:**
1. User clicks option button
2. Store `{qid, picked, bobot}` into `userAnswers[currentIdx]`
3. Add `.selected` class to clicked option, `disabled` to all options
4. `setTimeout(nextQuestion, 380)` — gives the user a moment of visual confirmation
5. If `currentIdx === TOTAL_SOAL - 1`, call `finishQuiz()` instead of advancing

**Finish Quiz** computes:
- Total score = `userAnswers.reduce((s, a) => s + a.bobot, 0)`
- Max score = 45 × 5 = 225
- Counts of correct (5) / partial (3–4) / wrong (1–2) / skipped (null)
- Performance message based on `pct = totalScore / maxScore * 100`

**Review Filter** — clicking a filter button calls `renderReview(filter)` which re-renders the list, skipping items whose `statusClass` doesn't match the filter.

**Quit Modal** — opens on "Akhiri" button click; "Ya, Akhiri" → call `finishQuiz()` immediately (unanswered remain marked as skipped because `userAnswers` is pre-initialized with `picked: null`).

**Beforeunload Guard:**
```js
window.addEventListener('beforeunload', (e) => {
  if (quizScreenVisible && currentIdx < TOTAL_SOAL - 1) {
    e.preventDefault();
    e.returnValue = '';
  }
});
```
Prevents accidental tab close mid-session.

### Materi Page

**Tab Switching:** Pure DOM toggling — only one `.section-pane` has `.active` at a time. Hash + localStorage drives initial state.

**Smooth Scroll to Top of Content** after switching (avoids jarring jump if user was scrolled deep into the previous module).

### Landing Page

Pure scroll/hover interactions — no JS state needed beyond the standard CSS transitions.

---

## State Management

### Quiz Page

State is local to the page — no global store needed. If lifting into React/Vue/etc., a single reducer (or composable) handles:
```
type QuizState = {
  status: 'idle' | 'running' | 'finished',
  soalList: Soal[],
  userAnswers: Answer[],
  currentIdx: number,
  timeLeft: number,
  startTime: number
}

type Action =
  | { type: 'START' }
  | { type: 'ANSWER'; letter: string }
  | { type: 'SKIP' }
  | { type: 'TICK' }
  | { type: 'FINISH' }
  | { type: 'RESTART' }
```

### Materi Page

A single `activeTab: 'A' | 'B' | 'C' | 'D' | 'E'` state, synced to URL hash (deep-linkable) and persisted to `localStorage` for return visits.

### Landing Page

Stateless.

### Data Fetching

None for v1 — the 150-question bank ships with the app. If you move to a CMS-backed flow later:
- `GET /api/soal` returns the full bank (still ~50KB compressed, totally fine to load upfront)
- Optionally `POST /api/attempts` to persist quiz results

---

## Design Tokens

All tokens live as CSS custom properties in `assets/style.css` under `:root`.

### Colors

| Token | Hex | Usage |
|---|---|---|
| `--bg-0` | `#050814` | Deepest background |
| `--bg-1` | `#0a0e1e` | Secondary background (scrollbar track, modal) |
| `--bg-2` | `#0f1530` | Tertiary background (panel inner) |
| `--surface` | `rgba(18, 24, 50, 0.6)` | Glass-surface cards (with backdrop-blur 12px) |
| `--surface-2` | `rgba(26, 34, 70, 0.8)` | Slightly denser surface |
| `--border` | `rgba(0, 240, 255, 0.18)` | Default 1px border on cards |
| `--border-strong` | `rgba(0, 240, 255, 0.45)` | Hover/active/highlighted border |
| `--cyan` | `#00f0ff` | Primary accent / brand |
| `--cyan-soft` | `#00d4ff` | Secondary cyan variant |
| `--purple` | `#b347ff` | Secondary accent (gradient partner) |
| `--magenta` | `#ff3da6` | Tertiary accent (gradient tail, blockquotes) |
| `--green` | `#00ff9d` | Success / correct answer |
| `--yellow` | `#ffd84d` | Warning / partial score |
| `--red` | `#ff4d6d` | Error / wrong score / danger timer |
| `--text-0` | `#e8ecff` | Primary text (headings, emphasized body) |
| `--text-1` | `#a8b3d9` | Secondary text (body paragraphs) |
| `--text-2` | `#6b7aa8` | Tertiary text (labels, metadata) |

### Glow / Shadows

| Token | Value |
|---|---|
| `--glow-cyan` | `0 0 24px rgba(0, 240, 255, 0.35)` |
| `--glow-purple` | `0 0 24px rgba(179, 71, 255, 0.35)` |

### Gradients

Used inline (not tokenized) — keep these constants in your theme file:
- **Brand gradient:** `linear-gradient(135deg, #00f0ff 0%, #b347ff 60%, #ff3da6 100%)` — used on `.gradient-text` headings, brand mark, primary CTAs
- **Accent bar:** `linear-gradient(180deg, #00f0ff, #b347ff)` — used on left edges of h2 accents and active card stripes
- **Holo panel base:** layered radial gradients (see "Holographic Panel" section above)

### Typography

| Family | Loaded | Usage |
|---|---|---|
| **Space Grotesk** (300, 400, 500, 600, 700) | Google Fonts | Display + body (`--font-display`) |
| **JetBrains Mono** (400, 500, 700) | Google Fonts | Code, metadata, labels, eyebrows (`--font-mono`) |

**Type scale (responsive via `clamp()`):**
- h1: `clamp(2.4rem, 5vw, 4rem)`, weight 700, line-height 1.05, letter-spacing -0.02em
- h2: `clamp(1.6rem, 3vw, 2.4rem)`, weight 600
- h3: 1.25rem, weight 600, color cyan
- Body: 1rem (16px default), line-height 1.6, color text-1
- Lead paragraph: 1.15rem, color text-1
- Eyebrow: 12px mono uppercase, letter-spacing 0.2em, color cyan, with a 24px-wide cyan dash prefix
- Meta/labels: 10–12px mono uppercase, letter-spacing 0.15–0.2em, color text-2

### Spacing Scale

Loosely on an 8px grid: 4, 8, 12, 16, 20, 24, 28, 32, 40, 48, 64, 80, 100. Card paddings typically 24–36px, sections 40–80px vertical.

### Border Radius

- Pill / tag: `100px`
- Button: `10px`
- Card / surface: `12px` (mini) / `16px` (standard) / `20px` (large) / `24px` (hero)

### Z-Index Layers

- Background grid: `0` (body::before, body::after)
- Page content: `1`
- Sticky quiz bar: `30`
- Sticky top nav: `50`
- Modal mask: `100`

### Animations

| Name | Keyframes | Duration / Easing | Used by |
|---|---|---|---|
| `gridMove` | `background-position: 0 → 60px` | `30s linear infinite` | Body background grid |
| `pulse-glow` | opacity + brightness pulse | `1.5s` (warning) / `0.8s` (danger) `ease-in-out infinite` | Timer warn/danger |
| `scanline` | `translateY: -100% → 100vh` | `4s linear infinite` | Holo panel scanline |
| `fadeIn` | opacity + translateY | `0.4s ease-out` | Material pane switch |
| `slideIn` | opacity + translateY 20px→0 | `0.35s cubic-bezier(0.16, 1, 0.3, 1)` | Quiz question card render |

### Backdrop Filter

`backdrop-filter: blur(12–20px) saturate(180%)` used on:
- Top nav (20px blur + saturate)
- All `.card` and `.surface` elements (12px blur)
- Modal mask (8px blur)
- Quiz sticky bar (16px blur)

---

## Assets

No bitmap images, icons, or external media are used in the prototype. Everything is rendered with CSS, gradients, and inline SVG.

The inline SVGs in `index.html` are simple stroke icons (arrow-right and clock) used inside CTA buttons:
```html
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
  <path d="M5 12h14M13 6l6 6-6 6"/>
</svg>
```
Replace with the codebase's icon library (Lucide, Heroicons, Phosphor, SF Symbols, Material Symbols — whatever is in use). Icon set used: arrow-right, clock.

**Fonts** (load from Google Fonts in the prototype):
```
https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap
```
In production: either self-host these fonts (preferred — performance + privacy), or use the codebase's existing font-loading mechanism.

**Question Bank Data** — `data/soal.js` exports `window.BANK_SOAL`, an array of 150 question objects. Each object:
```ts
type Soal = {
  id: number;                                          // 1..150
  bagian: 'A' | 'B' | 'C' | 'D' | 'E';                  // module
  pertanyaan: string;                                  // question text (HTML-safe plain text)
  opsi: { A: string; B: string; C: string; D: string; E: string };
  bobot: { A: number; B: number; C: number; D: number; E: number };  // each 1–5
  kunci: 'A' | 'B' | 'C' | 'D' | 'E';                   // option with bobot === 5
  pembahasan: string;                                  // explanation shown in review
};
```
Port this as a `.json` file or DB seed. The data is the canonical source of truth — DO NOT regenerate or paraphrase.

---

## Content / Copy

All copy in the prototype is in **Bahasa Indonesia** — keep it as-is. The curriculum content in `materi.html` was authored to match the **2025–2026** regulatory landscape:
- PermenPAN-RB No. 5 Tahun 2025 (replaces No. 62/2018)
- UU No. 20 Tahun 2023 tentang ASN (replaces UU No. 5/2014)
- SE MenPANRB No. 20 Tahun 2021 (BerAKHLAK core values)
- PP No. 94 Tahun 2021 (Disiplin PNS)
- PermenPANRB No. 6 Tahun 2022 (Pengelolaan Kinerja)
- PermenPAN-RB No. 19 Tahun 2025 (Sistem Merit)

Do not paraphrase regulation numbers, dates, or article references — they are factually used in the question bank too and must stay consistent.

---

## Responsive Behavior

| Breakpoint | Change |
|---|---|
| `< 980px` | Materi: sidebar collapses above content (single column) |
| `< 900px` | Landing: hero collapses to single column |
| `< 700px` | Two-column mini-card grids → single column |
| `< 600px` | Quiz: progress bar moves to a third row in quiz bar; question card padding reduced (24px 20px); question text down to 1rem; score display down to 3.5rem |

Module grid uses `auto-fit, minmax(280px, 1fr)` so it reflows naturally across all widths.

The fixed-grid background `60px × 60px` is decorative; no responsive adjustment needed.

---

## Accessibility Notes

The prototype is keyboard-navigable (all interactive elements are `<button>` or `<a>` tags). When recreating:
- Keep `<button>` semantics for quiz options (NOT `<div onclick>`)
- Ensure each option's accessible name includes the letter + text ("Opsi A: ...")
- Timer should announce "5 menit tersisa" / "1 menit tersisa" to screen readers when crossing the thresholds (use `aria-live="polite"` on a hidden region)
- Modal should trap focus when open; first focusable should receive focus on open
- Color contrast meets WCAG AA on the primary text colors against `--bg-0` — verify if you adjust any token

---

## Files in This Bundle

| File | What It Is |
|---|---|
| `index.html` | Landing page prototype |
| `materi.html` | 5-module learning material prototype (tabs) |
| `latihan.html` | Quiz simulator prototype (start → quiz → result) |
| `assets/style.css` | Global design tokens, base typography, shared components |
| `data/soal.js` | The 150-question bank + `pickRandomSoal()` helper. **Port the data as-is.** |

Open `index.html` in a browser to see the full flow end-to-end. The pages are linked via standard `<a href>` — no router needed for the prototype.

---

## Implementation Checklist for the Developer

- [ ] Set up the target framework's project structure (routes for `/`, `/materi`, `/latihan`)
- [ ] Port `data/soal.js` → `data/soal.json` (or DB seed)
- [ ] Define the design tokens in the target system (CSS vars, Tailwind config, theme object, SwiftUI Color extensions, etc.)
- [ ] Recreate the typography setup (Space Grotesk + JetBrains Mono)
- [ ] Build the landing page (hero + module grid + CTA banner)
- [ ] Build the materi page with tab routing (URL hash or framework router)
- [ ] Build the quiz engine: state machine (idle/running/finished), timer with warning thresholds, auto-advance on answer, skip handling
- [ ] Build the result + review screens with filter buttons
- [ ] Add the beforeunload guard during active quiz
- [ ] Polish: animations (slideIn on question render, scanline on holo panel, pulse on timer states)
- [ ] Accessibility pass (focus trap in modal, aria-live for timer thresholds, keyboard nav)
- [ ] Responsive QA across the breakpoints above
